
# My Paper Title

This repository is the official implementation of [Class-Incremental Few-Shot Object Detection with Progressive Parameter Exploration]. 
 
Our code is based on the open source code of "Meta R-CNN : Towards General Solver for Instance-level Low-shot Learning." 
```
## Requirements

To install requirements:


pip install cython
pip install cffi
pip install opencv-python
pip install scipy-1.2.0
pip install msgpack
pip install easydict
pip install matplotlib
pip install pyyaml
pip install tensorboardX
pip install pickle


cd lib
python setup.py build develop

Note: Please ensure that cuda version in your environment is 10.0, we recommend you to use annaconda to build pytorch 1.4 (along with cudatoolkit10.0)

Download coco2014 dataset (https://cocodataset.org/#home) and put the 'images' and 'annotations' into folder'/data/coco/'
Download and place the file 'resnet50-caffe.pth' in '/data/pretrained_model/'

Download and place all other files 

model pretrained on base set : 'coco_metarcnn_1_1_5000_cos_continue.pth'

model trained with PPE :  'coco_metarcnn_2_6_0_session_20_ex.pth'

in '/models/meta/first/'

You can download the above pretrained models here:

https://www.dropbox.com/sh/o156ml0hwlcmgue/AAAXBfReh6S_23L-xiqf_3uva?dl=0

## Training

To train the model(s) in the paper, run this command:


```train baseline method IMM in 20 steps 
CUDA_VISIBLE_DEVICES=0,1 python3.6 train_metarcnn_IMM.py --dataset coco --epochs 9 --bs 4 --nw 4 --log_dir checkpoint --save_dir models/meta/first --phase 2 --cag True  --r True --mGPUs
```

```train our method PPE in 20 steps 
CUDA_VISIBLE_DEVICES=0,1 python3.6 train_metarcnn_PPE.py --dataset coco --epochs 9 --bs 4 --nw 4 --log_dir checkpoint --save_dir models/meta/first --phase 2 --cag True  --r True --mGPUs
```


## Evaluation

To evaluate my model on COCO2014, run:


```evaluate model 
CUDA_VISIBLE_DEVICES=0 python3.6 test_metarcnn.py --dataset coco --net metarcnn --load_dir models/meta/first  --phase 2 --cag True
```

```trained models are stored in '/models/meta/first/',please mannualy replace the model name when necessary




## Contributing

Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License
Copyright (c) 2021, National University of Singapore

Only allow to download the code. Cannot change them in any way or use them commercially. For any other purpose you must contact the authors for permission. This code may not be redistributed without written permission from the authors.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

