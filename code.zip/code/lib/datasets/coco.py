# --------------------------------------------------------
# Fast/er R-CNN
# Licensed under The MIT License [see LICENSE for details]
# Written by Ross Girshick and Xinlei Chen
# --------------------------------------------------------
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from datasets.imdb import imdb
import datasets.ds_utils as ds_utils
from model.utils.config import cfg
import os.path as osp
import sys
import os
import numpy as np
import scipy.sparse
import scipy.io as sio
import pickle
import json
import uuid
# COCO API
from pycocotools.coco import COCO
from pycocotools.cocoeval import COCOeval
#from pycocotools import mask as COCOmask

class coco(imdb):
  def __init__(self, image_set, year):
    imdb.__init__(self, 'coco_' + year + '_' + image_set)
    # COCO specific config options
    self.config = {'use_salt': True,
                   'cleanup': True}
    # name, paths
    self._year = year
    self._image_set = image_set
    self._data_path = osp.join(cfg.DATA_DIR, 'coco')
    # load COCO API, classes, class <-> id mappings
    self._COCO = COCO(self._get_ann_file())
    cats = self._COCO.loadCats(self._COCO.getCatIds())
    self._classes = tuple(['__background__'] + [c['name'] for c in cats])
    
    #print(self._classes)
    self._class_to_ind = dict(list(zip(self.classes, list(range(self.num_classes)))))
    print(self._class_to_ind)

    
    self._class_to_ind = {'__background__': 0, 'truck': 1, 'traffic light': 2, 'fire hydrant': 3, 'stop sign': 4, 
                          'parking meter': 5, 'bench': 6, 'elephant': 7, 'bear': 8, 'zebra': 9, 
                          'giraffe': 10, 'backpack': 11, 'umbrella': 12, 'handbag': 13, 'tie': 14, 'suitcase': 15, 
                          'frisbee': 16, 'skis': 17, 'snowboard': 18, 'sports ball': 19, 'kite': 20, 'baseball bat': 21, 
                          'baseball glove': 22, 'skateboard': 23, 'surfboard': 24, 'tennis racket': 25, 
                          'wine glass': 26, 'cup': 27, 'fork': 28, 'knife': 29, 'spoon': 30, 'bowl': 31, 'banana': 32, 
                          'apple': 33, 'sandwich': 34, 'orange': 35, 'broccoli': 36, 'carrot': 37, 'hot dog': 38, 
                          'pizza': 39, 'donut': 40, 'cake': 41, 'bed': 42, 'toilet': 43, 'laptop': 44, 'mouse': 45, 'remote': 46,
                          'keyboard': 47, 'cell phone': 48, 'microwave': 49, 'oven': 50, 'toaster': 51, 'sink': 52,
                          'refrigerator': 53, 'book': 54, 'clock': 55, 'vase': 56, 'scissors': 57, 'teddy bear': 58, 
                          'hair drier': 59, 'toothbrush': 60, 'airplane': 61, 'bicycle': 62, 'boat': 63, 'bottle': 64,'car': 65, 'cat': 66, 'chair': 67, 
                           'dining table': 68, 'dog': 69, 'horse': 70, 'person': 71, 'potted plant': 72, 'sheep': 73, 
                           'train': 74,  'tv': 75,'bird': 76, 'bus': 77, 'cow': 78, 'motorcycle': 79, 'couch': 80}
    
    self._novel_cls_ind = {'airplane': 61, 'bicycle': 62, 'boat': 63, 'bottle': 64,'car': 65, 'cat': 66, 'chair': 67, 
                           'dining table': 68, 'dog': 69, 'horse': 70, 'person': 71, 'potted plant': 72, 'sheep': 73, 
                           'train': 74,  'tv': 75,'bird': 76, 'bus': 77, 'cow': 78, 'motorcycle': 79, 'couch': 80 }
    self._novel_cls = ['airplane', 'bicycle', 'boat', 'bottle','car', 'cat', 'chair', 
                           'dining table', 'dog', 'horse', 'person', 'potted plant', 'sheep', 
                           'train',  'tv','bird', 'bus', 'cow', 'motorcycle', 'couch' ]
    
    '''
    self._class_to_ind ={'__background__': 0, 'person': 1, 'bicycle': 2, 'car': 3,
                         'airplane': 4, 'bus': 5, 'train': 6, 'boat': 7,
                         'traffic light': 8, 'fire hydrant': 9,
                         'parking meter': 10, 'bench': 11, 'bird': 12, 'dog': 13,
                         'horse': 14, 'sheep': 15,'elephant': 16, 'bear': 17,
                         'zebra': 18, 'backpack': 19, 'umbrella': 20,
                         'handbag': 21,'suitcase': 22, 'frisbee': 23,
                         'skis': 24,'sports ball': 25, 'kite': 26, 
                         'baseball bat': 27, 'skateboard': 28,
                         'surfboard': 29, 'tennis racket': 30, 'wine glass': 31,
                         'cup': 32, 'fork': 33, 'spoon': 34, 'bowl': 35, 
                         'banana': 36, 'sandwich': 37, 'orange': 38, 'broccoli': 39,
                          'hot dog': 40, 'pizza': 41, 'donut': 42,
                         'chair': 43, 'couch': 44, 'potted plant': 45,
                         'dining table': 46, 'toilet': 47, 'tv': 48, 
                         'mouse': 49, 'remote': 50, 'keyboard': 51,
                         'microwave': 52, 'oven': 53, 'toaster': 54,
                         'refrigerator': 55, 'book': 56, 'clock': 57,
                         'scissors': 58, 'teddy bear': 59, 'hair drier': 60,'motorcycle': 61,
                         'truck': 62, 'stop sign': 63,  'cat': 64, 'cow': 65,
                          'giraffe': 66,  'tie': 67,  'snowboard': 68, 'baseball glove': 69, 
                          'bottle': 70, 'knife': 71, 'apple': 72,'carrot': 73,  'cake': 74,
                          'bed': 75,'laptop': 76,'cell phone': 77, 'sink': 78, 'vase': 79, 'toothbrush': 80}
    
    self._novel_cls_ind ={ 'motorcycle': 4, 'truck': 8, 'stop sign': 12,  'cat': 16, 'cow': 20,
                          'giraffe': 24,  'tie': 28,  'snowboard': 32, 'baseball glove': 36,  'bottle': 40,
                          'knife': 44, 'apple': 48,'carrot': 52,  'cake': 56, 'bed': 60,'laptop': 64,
                           'cell phone': 68, 'sink': 72, 'vase': 76, 'toothbrush': 80}
    
    self._novel_cls = { 'motorcycle', 'truck', 'stop sign',  'cat', 'cow',
                          'giraffe',  'tie',  'snowboard', 'baseball glove',  'bottle',
                          'knife', 'apple','carrot',  'cake', 'bed','laptop',
                           'cell phone', 'sink', 'vase', 'toothbrush'}
    '''
    self._class_to_coco_cat_id = dict(list(zip([c['name'] for c in cats],
                                               self._COCO.getCatIds())))
    #print(self._class_to_coco_cat_id)
    self._image_index = self._load_image_set_index()
    # Default to roidb handler
    self.set_proposal_method('gt')
    self.competition_mode(False)

    # Some image sets are "views" (i.e. subsets) into others.
    # For example, minival2014 is a random 5000 image subset of val2014.
    # This mapping tells us where the view's images and proposals come from.
    self._view_map = {
      'minival2014': 'val2014',  # 5k val2014 subset
      'valminusminival2014': 'val2014',  # val2014 \setminus minival2014
      'test-dev2015': 'test2015',
      'valminuscapval2014': 'val2014',
      'capval2014': 'val2014',
      'captest2014': 'val2014'
    }
    coco_name = image_set + year  # e.g., "val2014"
    self._data_name = (self._view_map[coco_name]
                       if coco_name in self._view_map
                       else coco_name)
    # Dataset splits that have ground-truth annotations (test splits
    # do not have gt annotations)
    self._gt_splits = ('train', 'val', 'minival')

  def _get_ann_file(self):
    prefix = 'instances' if self._image_set.find('test') == -1 \
      else 'image_info'
    return osp.join(self._data_path, 'annotations',
                    prefix + '_' + self._image_set + self._year + '.json')

  def _load_image_set_index(self):
    """
    Load image ids.
    """
    image_ids = self._COCO.getImgIds()
    return image_ids

  def _get_widths(self):
    anns = self._COCO.loadImgs(self._image_index)
    widths = [ann['width'] for ann in anns]
    return widths

  def image_path_at(self, i):
    """
    Return the absolute path to image i in the image sequence.
    """
    return self.image_path_from_index(self._image_index[i])

  def image_id_at(self, i):
    """
    Return the absolute path to image i in the image sequence.
    """
    return self._image_index[i]

  def image_path_from_index(self, index):
    """
    Construct an image path from the image's "index" identifier.
    """
    # Example image path for index=119993:
    #   images/train2014/COCO_train2014_000000119993.jpg
    file_name = ('COCO_' + self._data_name + '_' +
                 str(index).zfill(12) + '.jpg')
    image_path = osp.join(self._data_path, 'images',
                          self._data_name, file_name)
    assert osp.exists(image_path), \
      'Path does not exist: {}'.format(image_path)
    return image_path

  def gt_roidb(self):
    """
    Return the database of ground-truth regions of interest.
    This function loads/saves from/to a cache file to speed up future calls.
    """
    cache_file = osp.join(self.cache_path, self.name + '_gt_roidb.pkl')
    if osp.exists(cache_file):
      with open(cache_file, 'rb') as fid:
        roidb = pickle.load(fid)
      print('{} gt roidb loaded from {}'.format(self.name, cache_file))
      return roidb

    gt_roidb = [self._load_coco_annotation(index)
                for index in self._image_index]

    with open(cache_file, 'wb') as fid:
      pickle.dump(gt_roidb, fid, pickle.HIGHEST_PROTOCOL)
    print('wrote gt roidb to {}'.format(cache_file))
    return gt_roidb

  def _load_coco_annotation(self, index):
    """
    Loads COCO bounding-box instance annotations. Crowd instances are
    handled by marking their overlaps (with all categories) to -1. This
    overlap value means that crowd "instances" are excluded from training.
    """
    im_ann = self._COCO.loadImgs(index)[0]
    width = im_ann['width']
    height = im_ann['height']

    annIds = self._COCO.getAnnIds(imgIds=index, iscrowd=None)
    objs = self._COCO.loadAnns(annIds)
    # Sanitize bboxes -- some are invalid
    valid_objs = []
    for obj in objs:
      x1 = np.max((0, obj['bbox'][0]))
      y1 = np.max((0, obj['bbox'][1]))
      x2 = np.min((width - 1, x1 + np.max((0, obj['bbox'][2] - 1))))
      y2 = np.min((height - 1, y1 + np.max((0, obj['bbox'][3] - 1))))
      if obj['area'] > 0 and x2 >= x1 and y2 >= y1:
        obj['clean_bbox'] = [x1, y1, x2, y2]
        valid_objs.append(obj)
    objs = valid_objs
    num_objs = len(objs)

    boxes = np.zeros((num_objs, 4), dtype=np.uint16)
    gt_classes = np.zeros((num_objs), dtype=np.int32)
    overlaps = np.zeros((num_objs, self.num_classes), dtype=np.float32)
    seg_areas = np.zeros((num_objs), dtype=np.float32)

    # Lookup table to map from COCO category ids to our internal class
    # indices
    coco_cat_id_to_class_ind = dict([(self._class_to_coco_cat_id[cls],
                                      self._class_to_ind[cls])
                                     for cls in self._classes[1:]])

    for ix, obj in enumerate(objs):
      cls = coco_cat_id_to_class_ind[obj['category_id']]
      boxes[ix, :] = obj['clean_bbox']
      gt_classes[ix] = cls
      seg_areas[ix] = obj['area']
      if obj['iscrowd']:
        # Set overlap to -1 for all classes for crowd objects
        # so they will be excluded during training
        overlaps[ix, :] = -1.0
      else:
        overlaps[ix, cls] = 1.0

    ds_utils.validate_boxes(boxes, width=width, height=height)
    overlaps = scipy.sparse.csr_matrix(overlaps)
    return {'width': width,
            'height': height,
            'boxes': boxes,
            'gt_classes': gt_classes,
            'gt_overlaps': overlaps,
            'flipped': False,
            'seg_areas': seg_areas}

  def _get_widths(self):
    return [r['width'] for r in self.roidb]

  def append_flipped_images(self):
    num_images = self.num_images
    widths = self._get_widths()
    for i in range(num_images):
      boxes = self.roidb[i]['boxes'].copy()
      oldx1 = boxes[:, 0].copy()
      oldx2 = boxes[:, 2].copy()
      boxes[:, 0] = widths[i] - oldx2 - 1
      boxes[:, 2] = widths[i] - oldx1 - 1
      assert (boxes[:, 2] >= boxes[:, 0]).all()
      entry = {'width': widths[i],
               'height': self.roidb[i]['height'],
               'boxes': boxes,
               'gt_classes': self.roidb[i]['gt_classes'],
               'gt_overlaps': self.roidb[i]['gt_overlaps'],
               'flipped': True,
               'seg_areas': self.roidb[i]['seg_areas']}

      self.roidb.append(entry)
    self._image_index = self._image_index * 2

  def _get_box_file(self, index):
    # first 14 chars / first 22 chars / all chars + .mat
    # COCO_val2014_0/COCO_val2014_000000447/COCO_val2014_000000447991.mat
    file_name = ('COCO_' + self._data_name +
                 '_' + str(index).zfill(12) + '.mat')
    return osp.join(file_name[:14], file_name[:22], file_name)

  def _print_detection_eval_metrics(self, coco_eval):
    IoU_lo_thresh = 0.5
    IoU_hi_thresh = 0.95

    def _get_thr_ind(coco_eval, thr):
      ind = np.where((coco_eval.params.iouThrs > thr - 1e-5) &
                     (coco_eval.params.iouThrs < thr + 1e-5))[0][0]
      iou_thr = coco_eval.params.iouThrs[ind]
      assert np.isclose(iou_thr, thr)
      return ind

    ind_lo = _get_thr_ind(coco_eval, IoU_lo_thresh)
    ind_hi = _get_thr_ind(coco_eval, IoU_hi_thresh)
    # precision has dims (iou, recall, cls, area range, max dets)
    # area range index 0: all area ranges
    # max dets index 2: 100 per image
    precision = \
      coco_eval.eval['precision'][ind_lo:(ind_hi + 1), :, :, 0, 2]
    ap_default = np.mean(precision[precision > -1])
    print(('~~~~ Mean and per-category AP @ IoU=[{:.2f},{:.2f}] '
           '~~~~').format(IoU_lo_thresh, IoU_hi_thresh))
    print('{:.1f}'.format(100 * ap_default))
    novel_ap = 0
    precision_matrix = np.zeros((20,10))
  
    precision_matrix_1 = np.zeros((1,10))
    precision_matrix_2 = np.zeros((1,10))
    precision_matrix_3 = np.zeros((1,10))
    precision_matrix_4 = np.zeros((1,10))
    precision_matrix_5 = np.zeros((1,10))
    precision_matrix_6 = np.zeros((1,10))
    precision_matrix_7 = np.zeros((1,10))
    precision_matrix_8 = np.zeros((1,10))
    precision_matrix_9 = np.zeros((1,10))
    precision_matrix_10 = np.zeros((1,10))
    precision_matrix_11 = np.zeros((1,10))
    precision_matrix_12 = np.zeros((1,10))
    precision_matrix_13 = np.zeros((1,10))
    precision_matrix_14 = np.zeros((1,10))
    precision_matrix_15 = np.zeros((1,10))
    precision_matrix_16 = np.zeros((1,10))
    precision_matrix_17 = np.zeros((1,10))
    precision_matrix_18 = np.zeros((1,10))
    precision_matrix_19 = np.zeros((1,10))
    precision_matrix_20 = np.zeros((1,10))

    
    base_ap = 0
    precision_matrix_base = np.zeros((60,10))
    i = 0
    j = 0
    s1= 0 
    s2 = 0 
    s3 = 0
    s4 = 0
    s5= 0 
    s6 = 0 
    s7 = 0
    s8 = 0
    s9= 0 
    s10 = 0 
    s11= 0 
    s12 = 0 
    s13 = 0
    s14 = 0
    s15= 0 
    s16 = 0 
    s17 = 0
    s18 = 0
    s19= 0 
    s20 = 0 
    
    
    
    for cls_ind, cls in enumerate(self.classes):
      
      if cls == '__background__':
        continue
      # minus 1 because of __background__
      precision = coco_eval.eval['precision'][ind_lo:(ind_hi + 1), :, cls_ind - 1, 0, 2]
      #print(cls)
      #print(precision.shape)
      pre_stage_precision = np.mean(precision, axis=1)
      #print(pre_stage_precision)
      ap = np.mean(precision[precision > -1])
      print(str(cls)+'   '+'{:.1f}'.format(100 * ap))
      
      #precision_matrix[i,:] = pre_stage_precision
      #i = i +1
      if cls in self._novel_cls:
          novel_ap = novel_ap + ap
          precision_matrix[i,:] = pre_stage_precision
          i = i +1
          
          if 60<self._novel_cls_ind[cls] and self._novel_cls_ind[cls]<=61:
              precision_matrix_1[s1,:] = pre_stage_precision
              s1 = s1+1
          if 61<self._novel_cls_ind[cls] and self._novel_cls_ind[cls]<=62:
              precision_matrix_2[s2,:] = pre_stage_precision
              s2 = s2+1
          if 62<self._novel_cls_ind[cls] and self._novel_cls_ind[cls]<=63:
              precision_matrix_3[s3,:] = pre_stage_precision
              s3 = s3+1
          if 63<self._novel_cls_ind[cls] and self._novel_cls_ind[cls]<=64:
              precision_matrix_4[s4,:] = pre_stage_precision
              s4 = s4+1
          if 64<self._novel_cls_ind[cls] and self._novel_cls_ind[cls]<=65:
              precision_matrix_5[s5,:] = pre_stage_precision
              s5 = s5+1
          if 65<self._novel_cls_ind[cls] and self._novel_cls_ind[cls]<=66:
              precision_matrix_6[s6,:] = pre_stage_precision
              s6 = s6+1
          if 66<self._novel_cls_ind[cls] and self._novel_cls_ind[cls]<=67:
              precision_matrix_7[s7,:] = pre_stage_precision
              s7 = s7+1
          if 67<self._novel_cls_ind[cls] and self._novel_cls_ind[cls]<=68:
              precision_matrix_8[s8,:] = pre_stage_precision
              s8 = s8+1
          if 68<self._novel_cls_ind[cls] and self._novel_cls_ind[cls]<=69:
              precision_matrix_9[s9,:] = pre_stage_precision
              s9 = s9+1
          if 69<self._novel_cls_ind[cls] and self._novel_cls_ind[cls]<=70:
              precision_matrix_10[s10,:] = pre_stage_precision
              s10 = s10+1

          if 70<self._novel_cls_ind[cls] and self._novel_cls_ind[cls]<=71:
              precision_matrix_11[s11,:] = pre_stage_precision
              s11 = s11+1
          if 71<self._novel_cls_ind[cls] and self._novel_cls_ind[cls]<=72:
              precision_matrix_12[s12,:] = pre_stage_precision
              s12 = s12+1
          if 72<self._novel_cls_ind[cls] and self._novel_cls_ind[cls]<=73:
              precision_matrix_13[s13,:] = pre_stage_precision
              s13 = s13+1
          if 73<self._novel_cls_ind[cls] and self._novel_cls_ind[cls]<=74:
              precision_matrix_14[s14,:] = pre_stage_precision
              s14 = s14+1
          if 74<self._novel_cls_ind[cls] and self._novel_cls_ind[cls]<=75:
              precision_matrix_15[s15,:] = pre_stage_precision
              s15 = s15+1
          if 75<self._novel_cls_ind[cls] and self._novel_cls_ind[cls]<=76:
              precision_matrix_16[s16,:] = pre_stage_precision
              s16 = s16+1
          if 76<self._novel_cls_ind[cls] and self._novel_cls_ind[cls]<=77:
              precision_matrix_17[s17,:] = pre_stage_precision
              s17 = s17+1
          if 77<self._novel_cls_ind[cls] and self._novel_cls_ind[cls]<=78:
              precision_matrix_18[s18,:] = pre_stage_precision
              s18 = s18+1
          if 78<self._novel_cls_ind[cls] and self._novel_cls_ind[cls]<=79:
              precision_matrix_19[s19,:] = pre_stage_precision
              s19 = s19+1
          if 79<self._novel_cls_ind[cls] and self._novel_cls_ind[cls]<=80:
              precision_matrix_20[s20,:] = pre_stage_precision
              s20 = s20+1
          
      if cls not in self._novel_cls:
          base_ap = base_ap + ap
          precision_matrix_base[j,:] = pre_stage_precision
          j = j +1
          
          
      
    #print(precision_matrix.shape)
    precision_matrix = np.mean(precision_matrix,axis = 0)
    precision_matrix_1 = np.mean(precision_matrix_1,axis = 0)
    precision_matrix_2 = np.mean(precision_matrix_2,axis = 0)
    precision_matrix_3 = np.mean(precision_matrix_3,axis = 0)
    precision_matrix_4 = np.mean(precision_matrix_4,axis = 0)
    precision_matrix_5 = np.mean(precision_matrix_5,axis = 0)
    precision_matrix_6 = np.mean(precision_matrix_6,axis = 0)
    precision_matrix_7 = np.mean(precision_matrix_7,axis = 0)
    precision_matrix_8 = np.mean(precision_matrix_8,axis = 0)
    precision_matrix_9 = np.mean(precision_matrix_9,axis = 0)
    precision_matrix_10 = np.mean(precision_matrix_10,axis = 0)
    precision_matrix_11 = np.mean(precision_matrix_11,axis = 0)
    precision_matrix_12 = np.mean(precision_matrix_12,axis = 0)
    precision_matrix_13 = np.mean(precision_matrix_13,axis = 0)
    precision_matrix_14 = np.mean(precision_matrix_14,axis = 0)
    precision_matrix_15 = np.mean(precision_matrix_15,axis = 0)
    precision_matrix_16 = np.mean(precision_matrix_16,axis = 0)
    precision_matrix_17 = np.mean(precision_matrix_17,axis = 0)
    precision_matrix_18 = np.mean(precision_matrix_18,axis = 0)
    precision_matrix_19 = np.mean(precision_matrix_19,axis = 0)
    precision_matrix_20 = np.mean(precision_matrix_20,axis = 0)

    #print(precision_matrix)
    print('session 1 mean ap '+ str(np.mean(precision_matrix_1)))
    print('session 2 mean ap '+ str(np.mean(precision_matrix_2)))
    print('session 3 mean ap '+ str(np.mean(precision_matrix_3)))
    print('session 4 mean ap '+ str(np.mean(precision_matrix_4)))
    print('session 5 mean ap '+ str(np.mean(precision_matrix_5)))
    print('session 6 mean ap '+ str(np.mean(precision_matrix_6)))
    print('session 7 mean ap '+ str(np.mean(precision_matrix_7)))
    print('session 8 mean ap '+ str(np.mean(precision_matrix_8)))
    print('session 9 mean ap '+ str(np.mean(precision_matrix_9)))
    print('session 10 mean ap '+ str(np.mean(precision_matrix_10)))

    print('session 11 mean ap '+ str(np.mean(precision_matrix_11)))
    print('session 12 mean ap '+ str(np.mean(precision_matrix_12)))
    print('session 13 mean ap '+ str(np.mean(precision_matrix_13)))
    print('session 14 mean ap '+ str(np.mean(precision_matrix_14)))
    print('session 15 mean ap '+ str(np.mean(precision_matrix_15)))
    print('session 16 mean ap '+ str(np.mean(precision_matrix_16)))
    print('session 17 mean ap '+ str(np.mean(precision_matrix_17)))
    print('session 18 mean ap '+ str(np.mean(precision_matrix_18)))
    print('session 19 mean ap '+ str(np.mean(precision_matrix_19)))
    print('session 20 mean ap '+ str(np.mean(precision_matrix_20)))

    
    print('novel mean ap '+ str(np.mean(precision_matrix)))
    precision_matrix_base = np.mean(precision_matrix_base,axis = 0)
    #print(precision_matrix_base)
    print('base mean ap '+ str(np.mean(precision_matrix_base)))
    print('~~~~ Summary metrics ~~~~')
    coco_eval.summarize()

  def _do_detection_eval(self, res_file, output_dir):
    ann_type = 'bbox'
    coco_dt = self._COCO.loadRes(res_file)
    coco_eval = COCOeval(self._COCO, coco_dt)
    coco_eval.params.useSegm = (ann_type == 'segm')
    coco_eval.evaluate()
    coco_eval.accumulate()
    self._print_detection_eval_metrics(coco_eval)
    eval_file = osp.join(output_dir, 'detection_results.pkl')
    with open(eval_file, 'wb') as fid:
      pickle.dump(coco_eval, fid, pickle.HIGHEST_PROTOCOL)
    print('Wrote COCO eval results to: {}'.format(eval_file))

  def _coco_results_one_category(self, boxes, cat_id):
    results = []
    
    for im_ind, index in enumerate(self.image_index):
      dets = boxes[im_ind].astype(np.float)
      if dets == []:
        continue
      scores = dets[:, -1]
      xs = dets[:, 0]
      ys = dets[:, 1]
      ws = dets[:, 2] - xs + 1
      hs = dets[:, 3] - ys + 1
      results.extend(
        [{'image_id': index,
          'category_id': cat_id,
          'bbox': [xs[k], ys[k], ws[k], hs[k]],
          'score': scores[k]} for k in range(dets.shape[0])])
    return results

  def _write_coco_results_file(self, all_boxes, res_file):
    # [{"image_id": 42,
    #   "category_id": 18,
    #   "bbox": [258.15,41.29,348.26,243.78],
    #   "score": 0.236}, ...]
    results = []
    for cls, cls_ind in sorted(self._class_to_ind.items()):
    #for cls_ind, cls in enumerate(self.classes):
      if cls == '__background__':
        continue
      print('Collecting {} results ({:d}/{:d})'.format(cls, cls_ind,
                                                       self.num_classes - 1))
      coco_cat_id = self._class_to_coco_cat_id[cls]
      results.extend(self._coco_results_one_category(all_boxes[cls_ind],
                                                     coco_cat_id))
    print('Writing results json to {}'.format(res_file))
    with open(res_file, 'w') as fid:
      json.dump(results, fid)

  def evaluate_detections(self, all_boxes, output_dir):
    res_file = osp.join(output_dir, ('detections_' +
                                     self._image_set +
                                     self._year +
                                     '_results'))
    if self.config['use_salt']:
      res_file += '_{}'.format(str(uuid.uuid4()))
    res_file += '.json'
    self._write_coco_results_file(all_boxes, res_file)
    # Only do evaluation on non-test sets
    if self._image_set.find('test') == -1:
      self._do_detection_eval(res_file, output_dir)
    # Optionally cleanup results json file
    if self.config['cleanup']:
      os.remove(res_file)

  def competition_mode(self, on):
    if on:
      self.config['use_salt'] = False
      self.config['cleanup'] = False
    else:
      self.config['use_salt'] = True
      self.config['cleanup'] = True
