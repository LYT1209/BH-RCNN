
import random
import time
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
import tqdm

import random
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable
import torchvision.models as models
from model.roi_layers import nms
import numpy as np
from model.utils.config import cfg
from model.rpn.rpn import _RPN
'''
from model.roi_pooling.modules.roi_pool import _RoIPooling
from model.roi_crop.modules.roi_crop import _RoICrop
from model.roi_align.modules.roi_align import RoIAlignAvg
'''
from model.roi_layers import ROIAlign, ROIPool
from model.rpn.proposal_target_layer_cascade import _ProposalTargetLayer
from model.rpn.proposal_target_layer import _ProposalTargetLayer_DCR

from copy import deepcopy
from model.utils.net_utils import _smooth_l1_loss, _crop_pool_layer, _affine_grid_gen, _affine_theta

from model.rpn.bbox_transform import bbox_transform_inv
from model.rpn.bbox_transform import clip_boxes
import numpy.random as npr
import cv2

def variable(t: torch.Tensor, use_cuda=True, **kwargs):
    if torch.cuda.is_available() and use_cuda:
        t = t.cuda()
    return Variable(t, **kwargs)

class EWC(object):
    def __init__(self, label, classification_weights,model: nn.Module, dataset: list):

        self.model = model
        self.dataset = dataset
        self.label = label
        self.classification_weights = classification_weights
        self.params = {n: p for n, p in self.model.named_parameters() if p.requires_grad}
        self._means = {}
        self._precision_matrices = self._diag_fisher()

        for n, p in deepcopy(self.params).items():
            self._means[n] = variable(p.data)

    def _diag_fisher(self):
        precision_matrices = {}
        for n, p in deepcopy(self.params).items():
            p.data.zero_()
            precision_matrices[n] = variable(p.data)

        self.model.eval()
        for input in self.dataset:
            self.model.zero_grad()
            input = variable(input)
            pooled_feat = self.model(input)
            feature = F.normalize(pooled_feat, p=2, dim=1)
            w = F.normalize(self.classification_weights, dim=1, p=2)
   
            cls_score = F.linear(feature, w)*torch.FloatTensor([10]).cuda()
            
            loss = F.cross_entropy(cls_score, self.label)
    
            loss.backward()

            for n, p in self.model.named_parameters():
                precision_matrices[n].data += p.grad.data ** 2 / len(self.dataset)

        precision_matrices = {n: p for n, p in precision_matrices.items()}
        #print('inside   '+str(precision_matrices.size()))
        return precision_matrices

def l2_loss(base_model,current_model):
    l2_lambda = 0.001
    l2_reg = torch.tensor(0.)

    m = 0
    for param in current_model.RCNN_top.parameters():
        n = 0
        for param_1 in base_model.module.RCNN_top.parameters():
            if n == m:
                print(m)
                print(n)
                print(param.size())
                print(param_1.size())
                l2_reg = l2_reg +  torch.norm(param-param_1.detach())
                break
            else:
                n = n +1
                
                
        m = m +1
        
    m = 0
    for param in current_model.RCNN_cls_score.parameters():
        n = 0
        for param_1 in base_model.module.RCNN_cls_score.parameters():
            if n == m:
                l2_reg = l2_reg +  torch.norm(param-param_1.detach())
                break
            else:
                n = n +1
                
                
        m = m +1
        
        
    m = 0
    for param in current_model.RCNN_bbox_pred.parameters():
        n = 0
        for param_1 in base_model.module.RCNN_bbox_pred.parameters():
            if n == m:
                l2_reg = l2_reg +  torch.norm(param-param_1.detach())
                break
            else:
                n = n +1
                
                
        m = m +1
    return l2_lambda *l2_reg
def mixup_criterion(criterion, pred, y_a, y_b, lam):
        return lam * criterion(pred, y_a) + (1 - lam) * criterion(pred, y_b)
def to_one_hot(inp,num_classes):

    y_onehot = torch.FloatTensor(inp.size(0), num_classes)
    if torch.cuda.is_available():
        y_onehot = y_onehot.cuda()

    y_onehot.zero_()
    x = inp.type(torch.LongTensor)
    if torch.cuda.is_available():
        x = x.cuda()

    x = torch.unsqueeze(x , 1)
    y_onehot.scatter_(1, x , 1)
    
    return Variable(y_onehot,requires_grad=False)
def mixup_data(x, y, lam):

    '''Compute the mixup data. Return mixed inputs, pairs of targets, and lambda'''
   
    batch_size = x.size()[0]
    index = torch.randperm(batch_size)
    if torch.cuda.is_available():
        index = index.cuda()
    mixed_x = lam * x + (1 - lam) * x[index,:]
    y_a, y_b = y, y[index]

    return mixed_x, y_a, y_b, lam   
def mixup_data_distill(x1, x2, lam):

    '''Compute the mixup data. Return mixed inputs, pairs of targets, and lambda'''
   
    batch_size = x1.size()[0]
    index = torch.randperm(batch_size)
    #if torch.cuda.is_available():
     #   index = index.cuda()
    mixed_x1 = lam * x1 + (1 - lam) * x1[index,:].cuda()
    mixed_x2 = lam * x2 + (1 - lam) * x2[index,:].to('cuda:0')

    return mixed_x1, mixed_x1
def mixup_data_sep(x, y, x_s,y_s, lam):

    '''Compute the mixup data. Return mixed inputs, pairs of targets, and lambda'''
    batch_size = x.size()[0]
    batch_size_s = x_s.size()[0]
    
    if batch_size > batch_size_s:
        index = np.arange(batch_size_s)
        index = npr.choice(index, size=batch_size, replace=True)
    else:
        index = np.arange(batch_size_s)
        index = npr.choice(index, size=batch_size, replace=False)
    
    index = torch.LongTensor(index).cuda()
    mixed_x = lam * x + (1 - lam) * x_s[index,:]
    y_a, y_b = y, y_s[index]

    return mixed_x, y_a, y_b, lam 
def softmax_kl_loss(input_logits, target_logits):
    """Takes softmax on both sides and returns KL divergence
    Note:
    - Returns the sum over all examples. Divide by the batch size afterwards
      if you want the mean.
    - Sends gradients to inputs but not the targets.
    """
    assert input_logits.size() == target_logits.size()
    input_log_softmax = F.log_softmax(input_logits, dim=1)
    target_softmax = F.softmax(target_logits, dim=1)
    num_classes = input_logits.size()[1]
    return F.kl_div(input_log_softmax, target_softmax, size_average=False) / num_classes

def softmax_mse_loss(input_logits, target_logits):
    """Takes softmax on both sides and returns MSE loss
    Note:
    - Returns the sum over all examples. Divide by the batch size afterwards
      if you want the mean.
    - Sends gradients to inputs but not the targets.
    """
    assert input_logits.size() == target_logits.size()
    input_softmax = F.softmax(input_logits, dim=1)
    target_softmax = F.softmax(target_logits, dim=1)
    #s_score,_=torch.max(input_softmax[:,1:],dim = 1)
    #t_score,_=torch.max(target_softmax[:,1:],dim = 1)
    #print(s_score.size())
    num_classes = input_logits.size()[1]
    #print(F.mse_loss(input_softmax, target_softmax, size_average=False).size())
    return F.mse_loss(input_softmax, target_softmax, size_average=False) / num_classes
def drift_loss(dcr_prediction, gt, cls_index):
    dcr_pred = dcr_prediction.data.cpu().numpy()
    gt = gt.data.cpu().numpy()
    
    select_logit_p = []
    select_logit_n = []
    
    #print(cls_index)
    for i in range(len(gt)):
            if gt[i]<=cls_index and gt[i]>0:
                ind = i
                gt_fg_ind = gt[ind]
                sec_max_ind = np.argsort(dcr_pred[ind,cls_index+1:])[-1]+cls_index+1
               
               
                #print(dcr_prediction[ind,gt_fg_ind].size())
                select_logit_p.append(dcr_prediction[ind,gt_fg_ind].view(1,1))
                select_logit_n.append(dcr_prediction[ind,sec_max_ind].view(1,1))
                
            if gt[i]>cls_index:
                ind = i
                gt_fg_ind = gt[ind]
                sec_max_ind = np.argsort(dcr_pred[ind,1:cls_index+1])[-1]+1
               
                #print(dcr_prediction[ind,gt_fg_ind].size())
                select_logit_p.append(dcr_prediction[ind,gt_fg_ind].view(1,1))
                select_logit_n.append(dcr_prediction[ind,sec_max_ind].view(1,1))
              
    if len(select_logit_p)>0:
        select_logit_p = torch.cat(select_logit_p, dim=0)    
        select_logit_n = torch.cat(select_logit_n, dim=0)
        mr_loss = nn.MarginRankingLoss(margin=0)(select_logit_p.view(-1, 1), \
                            select_logit_n.view(-1, 1), torch.ones(len(select_logit_p)).cuda())
    else:
        mr_loss = 0
    
    return mr_loss



class _fasterRCNN(nn.Module):
    """ faster RCNN """
    
    def __init__(self, classes, class_agnostic):
        super(_fasterRCNN, self).__init__()
        self.classes = classes
        self.n_classes = len(classes)
        self.class_agnostic = class_agnostic
         
        # loss
        self.RCNN_loss_cls = 0
        self.RCNN_loss_bbox = 0
        
        # define rpn
        self.RCNN_rpn = _RPN(self.dout_base_model)
        self.RCNN_proposal_target = _ProposalTargetLayer(self.n_classes)
        self.RCNN_proposal_target_DCR = _ProposalTargetLayer_DCR(self.n_classes)

        self.RCNN_roi_pool = ROIPool((cfg.POOLING_SIZE, cfg.POOLING_SIZE), 1.0/16.0)
        self.RCNN_roi_align = ROIAlign((cfg.POOLING_SIZE, cfg.POOLING_SIZE), 1.0/16.0, 0)
        self.DCR_roi_align = ROIAlign((224, 224), 1.0,0 )
       
      

    def forward(self, im_data=None, im_info=None, gt_boxes=None, num_boxes=None,FRCN_old = None,n_shots =1,start_class = -1,train_specific_branch = False,train_agnostic_branch=False,train_specific_rcnn = False,train_agnoist_rcnn=False,ROI_feature = None, ROI_label=None, extract_ROI_feature_base=False,extract_feature_wo_normal=False,train_with_additional_and_mixup=False, saved_feature = None,extract_ROI_feature = False,test_dcr_clean=False,saved_cls = None,test_voc=False,extract_feature=False,train_with_additional=False, cls_index=None,base_model = None, pretrain = False,phase = None,dcr=None,train_dcr = False,test_trans=False,ranking_loss=False,reweight_net = False,train_reweight_net=False, train_top=False,combine_feature = False,fasterRCNN_t = None, extract_feature_novel=False,extract_feature_base = False, finetune=False,imprint_rcnn=False,train_fc=False,rfcn_ft=False,train_dcr_unlabel = False,protype_finetune=False,sample_per_img= 32,imprint = False, test_dcr = False,remove_fp = False,fg = 0.25, fp = 0.4,train_dcr_balance=False,novel=False,rate=None,distillation=False,dcr_net=None,FRCN_teacher=None,unlabel=False,semi=False, unlabel_rcnn=False,unlabel_nms=False,train_IOUNet=False,train_dcr_bg=False,rcnn_head=False,train_noisy_base=False,train_clean_base=False):
    #def forward(self, im_data, im_info, gt_boxes, num_boxes,n_shots =1,  phase = None,dcr=None,train_dcr = False,extract_feature=False, finetune=False,imprint_rcnn=False,rfcn_ft=False,train_dcr_unlabel = False,protype_finetune=False,sample_per_img= 32,imprint = False, test_dcr = False,remove_fp = False,fg = 0.25, fp = 0.4,novel=False):
        # return attentions for testing
        

        
        batch_size = im_data.size(0)

        im_info = im_info.data
        gt_boxes = gt_boxes.data
        
        #print(start_class)
        
        if start_class>0:
            for k in range(batch_size):
                gt_label = gt_boxes[k][:,4].cpu().numpy()
                #print(gt_label)
                distractor_index = np.where((gt_label>0)&(gt_label!=start_class))[0]
                #print(len(distractor_index))
                if len(distractor_index)>0:
                    for n in range(len(distractor_index)):
                        distractor = int(distractor_index[n])
                        gt_boxes[k][distractor,:] = 0
        
        #print(gt_boxes)  
        im_info = im_info.data
        gt_boxes = gt_boxes.data
        num_boxes = num_boxes.data
        #print('gt_boxes '+str(gt_boxes.size()))
        base_feat = self.RCNN_base(im_data)
        #print(base_feat.size())
        rois,rois_num,rpn_loss_cls, rpn_loss_bbox = self.RCNN_rpn(base_feat, im_info, gt_boxes, num_boxes)
        rois_0 = Variable(torch.cat(rois,dim=0))
        
        
        #print(rois_0.size())
        #print(rois_0)
        # if it is training phrase, then use ground trubut bboxes for refining
        if self.training :
            roi_data = self.RCNN_proposal_target(rois_0, gt_boxes, num_boxes)
            rois_1, rois_label, rois_target, rois_inside_ws, rois_outside_ws,iou = roi_data
            #print(iou.size())
            rois_label = Variable(rois_label.view(-1).long())
          
            rois_target = Variable(rois_target.view(-1, rois_target.size(2)))
            rois_inside_ws = Variable(rois_inside_ws.view(-1, rois_inside_ws.size(2)))
            rois_outside_ws = Variable(rois_outside_ws.view(-1, rois_outside_ws.size(2)))
        else:
            rois_1 = rois_0
            rois_label = None
            #print('test dcr')
            rois_target = None
            rois_inside_ws = None
            rois_outside_ws = None
            rpn_loss_cls = 0
            rpn_loss_bbox = 0

        #rois = Variable(rois)
       
        # do roi pooling based on predicted rois
        #rois = Variable(rois)
        ###select_rois = Variable(select_rois)
 
        # do roi pooling based on predicted rois
        
        #print(rois_0.size())
        if cfg.POOLING_MODE == 'align' and not imprint_rcnn:
            pooled_feat_0 = self.RCNN_roi_align(base_feat, rois_1.view(-1, 5))
            pooled_feat = self._head_to_tail(pooled_feat_0)
            '''
            if not train_fc:
                
                pooled_feat_old =FRCN_old.module._head_to_tail(pooled_feat_0.detach().to("cuda:0"))
                w = FRCN_old.module.RCNN_cls_score.weight
               


                w = F.normalize(w, dim=1, p=2)
            
                teacher_cls_score = F.linear(F.normalize(pooled_feat_old, dim=1, p=2), w).detach().cpu().cuda()*torch.FloatTensor([10]).cuda()
                scores = F.softmax(teacher_cls_score, 1)
                numpy_score = scores[:,1:start_class+1].detach().cpu().numpy()
                #print(scores[:,60:].size())
                pusedo_cls = np.argmax(numpy_score,axis = 1)+1
                max_logit = numpy_score.max(axis=1)
                #print(np.mean(max_logit))
                threshold = 0.18


                
                ###fg_index = np.where(max_logit>=threshold )[0]
                ###ignore_index = np.where((max_logit>=0.13)&(max_logit<0.18) )[0]
                ###bg_index = np.where(max_logit<0.13 )[0]
                ###pusedo_cls[bg_index] = 0
                ###pusedo_cls[ignore_index] = -1
                
                fg_index = np.where(max_logit>=threshold )[0]
                
                bg_index = np.where(max_logit<threshold )[0]
                pusedo_cls[bg_index] = 0
           

                #print(pusedo_cls[fg_index])
                original_gt = rois_label.squeeze().cpu().numpy()


                
                ###for m in range(len(original_gt)):
                ###    if original_gt[m] ==start_class:
                ###        pusedo_cls[m] = original_gt[m] 
                
                ###gt_fg_index = np.where((original_gt>0 )& (original_gt != start_class))[0]
                ###gt_bg_index = np.where(original_gt==0 )[0]


                ###correct_fg = np.where(pusedo_cls[gt_fg_index] == original_gt[gt_fg_index])[0]
                ###correct_bg = np.where(pusedo_cls[gt_bg_index] == original_gt[gt_bg_index])[0]
                ###if len(gt_fg_index)>0:
                ###    print('fg   '+str(len(correct_fg)/len(gt_fg_index))+'   bg   '+str(len(correct_bg)/len(gt_bg_index)))
                


                for m in range(len(original_gt)):
                    if original_gt[m] ==0 and pusedo_cls[m]>0 :
                        original_gt[m] = pusedo_cls[m]
                #print(len(np.where(original_gt>0 )[0])/len(original_gt))
                rois_label = torch.LongTensor(original_gt).cuda()
                final_fg_index = torch.LongTensor(np.where(original_gt>0)[0]).cuda()
           '''
        if imprint_rcnn:
            pooled_feat_all = self.RCNN_roi_align(base_feat, rois_0.view(-1, 5))
            pooled_feat_all = self._head_to_tail(pooled_feat_all)
           

            
            
      
            
            
        if combine_feature:
            #teacher_feat = fasterRCNN_t.module.RCNN_base(im_data)
            pooled_teacher_feat_0 = self.RCNN_roi_align(base_feat, rois_1.view(-1, 5))
            pooled_teacher_feat = fasterRCNN_t._head_to_tail(pooled_teacher_feat_0)
            
            
            
        
        #all_pooled_feat = self._head_to_tail(all_pooled_feat)
        

        if imprint_rcnn:
            cls_prob_list = []
            bbox_pred_list = []
            
            
            RCNN_loss_cls = 0
            RCNN_loss_bbox = 0
            
            DCR_rois = rois_0
            #batch_size = 4
            
            DCR_input = []
            DCR_input_cls = []
            
            batch_roi_max_classes = []
            
            
            for b in range(batch_size):
                
                
                channel_wise_feat =  pooled_feat_all
                bbox_pred = self.RCNN_bbox_pred(channel_wise_feat)  # 128 * 4
                
                bbox_pred = bbox_pred.view(1, DCR_rois.size(1), -1)
               ### scores = cls_prob.data
                #print(scores.size())
                boxes = DCR_rois.data[b, :, 1:5].unsqueeze(dim=0)
                #print(rois.size())
                if cfg.TEST.BBOX_REG:
                    # Apply bounding-box regression deltas
                    box_deltas = bbox_pred.data
                    if cfg.TRAIN.BBOX_NORMALIZE_TARGETS_PRECOMPUTED:
                        # Optionally normalize targets by a precomputed mean and stdev
                        if self.class_agnostic:
                            box_deltas = box_deltas.view(-1, 4) * torch.FloatTensor(
                                cfg.TRAIN.BBOX_NORMALIZE_STDS).cuda() \
                                         + torch.FloatTensor(cfg.TRAIN.BBOX_NORMALIZE_MEANS).cuda()
                            box_deltas = box_deltas.view(1, -1, 4)

                    pred_boxes = bbox_transform_inv(boxes, box_deltas, 1)
                    pred_boxes = clip_boxes(pred_boxes, im_info, 1)

                pred_boxes = pred_boxes.squeeze()
                num_box = len(np.where(gt_boxes[b,:,4].cpu().numpy()!=0)[0])
                gt_cls = gt_boxes[b][0:num_box,4].cpu().numpy()
                
                roi_max_overlaps, gt_assignment,roi_max_classes,_ = self.RCNN_proposal_target_DCR(pred_boxes, gt_boxes[b].unsqueeze(0))
                #print(num_box)
                ground_truth_boxes = gt_boxes[b,:num_box,0:4]
                roi_pred_boxes = pred_boxes
                #print(ground_truth_boxes.size())
                #print(roi_pred_boxes.size())
                gt_with_pred_boxes = torch.cat((ground_truth_boxes,roi_pred_boxes),0)
                gt_with_pred_boxes = gt_with_pred_boxes.cpu().numpy()
                
                roi_max_overlaps = roi_max_overlaps.squeeze()
                gt_assignment = gt_assignment.squeeze()
                roi_max_classes = roi_max_classes.squeeze()
                ###roi_pred_classes = pred_scores.cpu().numpy().argmax(axis=1)
                #print('pred_scores'+str(pred_scores.shape))            
                roi_max_overlaps = roi_max_overlaps.cpu().numpy()
                
                roi_max_classes = roi_max_classes.cpu().numpy()
                
                roi_max_classes[np.where(roi_max_overlaps < cfg.TRAIN.FG_THRESH)] = 0
                
                if num_box==0:
                    continue


               
             
                DCR_input_feat = F.normalize(pooled_feat_all, p=2, dim=1)
                selected_boxes_cls = torch.LongTensor(roi_max_classes).cuda()
                
                DCR_input.append(DCR_input_feat)
                DCR_input_cls.append(selected_boxes_cls)

               
            if len(DCR_input)>0:
                DCR_input = torch.cat(DCR_input, dim = 0)
                DCR_input_cls = torch.cat(DCR_input_cls, dim = 0)
     
            return DCR_input,DCR_input_cls
        

        
        elif test_dcr_clean:
            
            
            base_fg_score,base_fg_num,novel_fg_score,novel_fg_num = 0,0,0,0
            
            
            
            
            base_fp = 0
            novel_fp = 0
            
            
           
            novel_fp_score = 0
            base_fp_score = 0
            cls_prob_list = []
            bbox_pred_list = []
            
                
            
            RCNN_loss_cls = 0
            RCNN_loss_bbox = 0
            
            DCR_rois = rois
            #batch_size = 4
            
            DCR_input = []
            DCR_input_cls = []
            DCR_input_new_cls = []
            batch_roi_max_classes = []
            batch_roi_max_classes_no_threshold = []
            rois_num = 600
            #print('batch_size '+str(batch_size))
            for b in range(batch_size):

                if b == 0:
                    channel_wise_feat =  pooled_feat[:rois_num, :]
               
                bbox_pred = self.RCNN_bbox_pred(channel_wise_feat)  # 128 * 4

                bbox_pred = bbox_pred.view(1, rois_num, -1)
                bbox_pred_for_test =  bbox_pred
                #cls_score = self.RCNN_cls_score(channel_wise_feat)
                #cls_prob = F.softmax(cls_score/2,dim=1).squeeze().data
                feature = F.normalize(pooled_feat, p=2, dim=1)
                #feature = pooled_feat
                w = self.RCNN_cls_score.weight
                w = F.normalize(w, dim=1, p=2)
          
                cls_score = F.linear(feature, w)*torch.FloatTensor([10]).cuda()
                cls_prob = F.softmax(cls_score,dim=1).squeeze().data
               ### scores = cls_prob.data
                #print(scores.size())
                pre_roi = DCR_rois[b][:rois_num, :]
                #print('pre   '+str(pre_roi.size()))
                boxes = pre_roi[:, 1:5].unsqueeze(dim=0).data
              
                    
                    
                    
            return rois, cls_prob,bbox_pred_for_test
        
       
        elif extract_feature:
            
            feature = F.normalize(pooled_feat, p=2, dim=1)
            
            select_index =torch.LongTensor( np.where(rois_label.cpu().numpy()>60)[0]).cuda()
            select_feature = feature[select_index].detach()
            cls_label = rois_label[select_index]
            
            

 
            return select_feature,cls_label
        
        elif extract_feature_wo_normal:
            
            #feature = F.normalize(pooled_feat, p=2, dim=1)
            feature = pooled_feat
            
            bg = np.where(rois_label.cpu().numpy()==0)[0]
            bg_index = torch.LongTensor(np.random.choice(bg,size=16) ).cuda()
            
            select_index =torch.LongTensor( np.where(rois_label.cpu().numpy()>0)[0]).cuda()
            
            select_index = torch.cat((select_index,bg_index),dim = 0)
            select_feature = feature[select_index].detach()
            cls_label = rois_label[select_index]
            
    
            

 
            return select_feature,cls_label
        
        elif extract_ROI_feature:
            
            #feature = F.normalize(pooled_feat, p=2, dim=1)
            feature = pooled_feat_0
            
            ###bg = np.where(rois_label.cpu().numpy()==0)[0]
            ###bg_index = torch.LongTensor(np.random.choice(bg,size=16) ).cuda()
            
            select_index =torch.LongTensor( np.where(rois_label.cpu().numpy()>0)[0]).cuda()
            
            ###select_index = torch.cat((select_index,bg_index),dim = 0)
            select_feature = feature[select_index].detach()
            cls_label = rois_label[select_index]

            reg_targets = rois_target[select_index]
            inside_ws = rois_inside_ws[select_index]
            outside_ws = rois_outside_ws[select_index]
            
    
            

 
            return select_feature,cls_label,reg_targets,inside_ws,outside_ws
        
        elif extract_ROI_feature_base:
            
            #feature = F.normalize(pooled_feat, p=2, dim=1)
            feature = pooled_feat_0
            
            ###bg = np.where(rois_label.cpu().numpy()==0)[0]
            ###bg_index = torch.LongTensor(np.random.choice(bg,size=16) ).cuda()
            fg_num = min(len(np.where(rois_label.cpu().numpy()>0)[0]),5)
            if fg_num >0:
                select_index =torch.LongTensor( npr.choice(np.where(rois_label.cpu().numpy()>0)[0], size=fg_num, replace=True)).cuda()
 
                select_feature = feature[select_index].detach()
                cls_label = rois_label[select_index]
                reg_targets = rois_target[select_index]
                inside_ws = rois_inside_ws[select_index]
                outside_ws = rois_outside_ws[select_index]
            else:
                select_index =torch.LongTensor( npr.choice(np.where(rois_label.cpu().numpy()==0)[0], size=fg_num, replace=True)).cuda()
 
                select_feature = feature[select_index].detach()
                cls_label = rois_label[select_index]
                reg_targets = rois_target[select_index]
                inside_ws = rois_inside_ws[select_index]
                outside_ws = rois_outside_ws[select_index]
            
    
            

 
            return select_feature,cls_label,reg_targets,inside_ws,outside_ws
        elif train_agnostic_branch:
       
            bbox_pred = self.RCNN_bbox_pred(pooled_feat)
            if self.training and not self.class_agnostic:
                # select the corresponding columns according to roi labels
                bbox_pred_view = bbox_pred.view(bbox_pred.size(0), int(bbox_pred.size(1) / 4), 4)
                bbox_pred_select = torch.gather(bbox_pred_view, 1,
                                                rois_label.view(rois_label.size(0), 1, 1).expand(rois_label.size(0), 1,
                                                                                                 4))
                bbox_pred = bbox_pred_select.squeeze(1)
     
 
            feature = F.normalize(pooled_feat, p=2, dim=1)
            w = self.RCNN_cls_score.weight
            w = F.normalize(w, dim=1, p=2)
  
      
            all_feature = feature
            raw_logit =  F.linear(all_feature, w)
            cls_score = F.linear(all_feature, w)*torch.FloatTensor([10]).cuda()
        
            RCNN_loss_cls = 0
            RCNN_loss_bbox = 0
            
            if self.training:
              
                numpy_label = rois_label.cpu().numpy()
                fg_index = torch.LongTensor(np.where(numpy_label>0)[0]).cuda()
                rois_label[fg_index] = 1
                   
                RCNN_loss_cls = F.cross_entropy(cls_score, rois_label)#+ 5*drift_loss(cls_score, rois_label,cls_index)#+softmax_mse_loss(cls_score[final_fg_index],teacher_cls_score[final_fg_index])#+ 5*drift_loss(cls_score, rois_label,cls_index)+softmax_mse_loss(cls_score[final_fg_index],teacher_cls_score[final_fg_index])
                RCNN_loss_bbox = _smooth_l1_loss(bbox_pred, rois_target, rois_inside_ws, rois_outside_ws)

 
            return rois,rpn_loss_cls, rpn_loss_bbox, RCNN_loss_cls, RCNN_loss_bbox
        elif train_specific_branch:
       
            bbox_pred = self.RCNN_bbox_pred(pooled_feat)
            if self.training and not self.class_agnostic:
                # select the corresponding columns according to roi labels
                bbox_pred_view = bbox_pred.view(bbox_pred.size(0), int(bbox_pred.size(1) / 4), 4)
                bbox_pred_select = torch.gather(bbox_pred_view, 1,
                                                rois_label.view(rois_label.size(0), 1, 1).expand(rois_label.size(0), 1,
                                                                                                 4))
                bbox_pred = bbox_pred_select.squeeze(1)
     
 
            feature = F.normalize(pooled_feat, p=2, dim=1)
            w = self.RCNN_cls_score.weight
            w = F.normalize(w, dim=1, p=2)
  
      
            all_feature = feature
            
            
            
            
            
            raw_logit =  F.linear(all_feature, w)
            cls_score = F.linear(all_feature, w)*torch.FloatTensor([10]).cuda()
        
            RCNN_loss_cls = 0
            RCNN_loss_bbox = 0
            
            if self.training:
              
                numpy_label = rois_label.cpu().numpy()
                fg_index = torch.LongTensor(np.where(numpy_label>0)[0]).cuda()
                rois_label = rois_label-1
                   
                RCNN_loss_cls = F.cross_entropy(cls_score[fg_index], rois_label[fg_index])#+ 5*drift_loss(cls_score, rois_label,cls_index)#+softmax_mse_loss(cls_score[final_fg_index],teacher_cls_score[final_fg_index])#+ 5*drift_loss(cls_score, rois_label,cls_index)+softmax_mse_loss(cls_score[final_fg_index],teacher_cls_score[final_fg_index])
                RCNN_loss_bbox = _smooth_l1_loss(bbox_pred, rois_target, rois_inside_ws, rois_outside_ws)

 
            return rois,rpn_loss_cls, rpn_loss_bbox, RCNN_loss_cls, RCNN_loss_bbox

        elif train_with_additional:
            lam = np.random.beta(1.5, 1.5)


            bbox_pred = self.RCNN_bbox_pred(pooled_feat)
            if self.training and not self.class_agnostic:
                # select the corresponding columns according to roi labels
                bbox_pred_view = bbox_pred.view(bbox_pred.size(0), int(bbox_pred.size(1) / 4), 4)
                bbox_pred_select = torch.gather(bbox_pred_view, 1,
                                                rois_label.view(rois_label.size(0), 1, 1).expand(rois_label.size(0), 1,
                                                                                                 4))
                bbox_pred = bbox_pred_select.squeeze(1)
            
            batch_roi_max_classes_no_threshold = []   
            batch_roi_max_classes = []
      
            select_index =torch.LongTensor( np.random.randint(len(saved_cls), size=min(32,len(saved_cls)))).cuda()
            select_feature = saved_feature[select_index]
            cls_label = saved_cls[select_index]
 
            feature = F.normalize(pooled_feat, p=2, dim=1)

            w = self.RCNN_cls_score.weight
            w = F.normalize(w, dim=1, p=2)
  
            select_feature = F.normalize(select_feature, p=2, dim=1)



            all_feature = torch.cat((feature,select_feature),dim=0)
            rois_label = torch.cat((rois_label,cls_label),dim = 0)
            #all_feature = feature
            #rois_label = rois_label
            
            
            
            raw_logit =  F.linear(all_feature, w)
            cls_score = F.linear(all_feature, w)*torch.FloatTensor([10]).cuda()
        
            RCNN_loss_cls = 0
            RCNN_loss_bbox = 0
            
            if self.training:
                # classification loss
                cls_prob =  F.softmax(cls_score, dim = 1)
                #print(cls_prob.size())
                numpy_label = rois_label.cpu().numpy()
                fg_index = torch.LongTensor(np.where(numpy_label>0)[0]).cuda()

                
                #print(len(fg_index))
                if train_fc:
                    RCNN_loss_cls = F.cross_entropy(cls_score, rois_label)+ 5*drift_loss(cls_score, rois_label,cls_index)
                else:
                   
                    RCNN_loss_cls = F.cross_entropy(cls_score, rois_label)+ 5*drift_loss(cls_score, rois_label,cls_index)#+softmax_mse_loss(cls_score[final_fg_index],teacher_cls_score[final_fg_index])#+ 5*drift_loss(cls_score, rois_label,cls_index)+softmax_mse_loss(cls_score[final_fg_index],teacher_cls_score[final_fg_index])
                RCNN_loss_bbox = _smooth_l1_loss(bbox_pred, rois_target, rois_inside_ws, rois_outside_ws)

 
            return rois,rpn_loss_cls, rpn_loss_bbox, RCNN_loss_cls, RCNN_loss_bbox
        
        elif train_with_additional_and_mixup:
            criterion = nn.CrossEntropyLoss()
            lam = np.random.beta(1.5, 1.5)
            
            
            #loss = mixup_criterion(criterion, outputs, target_a, target_b, lam)
            bbox_pred = self.RCNN_bbox_pred(pooled_feat)
            if self.training and not self.class_agnostic:
                # select the corresponding columns according to roi labels
                bbox_pred_view = bbox_pred.view(bbox_pred.size(0), int(bbox_pred.size(1) / 4), 4)
                bbox_pred_select = torch.gather(bbox_pred_view, 1,
                                                rois_label.view(rois_label.size(0), 1, 1).expand(rois_label.size(0), 1,
                                                                                                 4))
                bbox_pred = bbox_pred_select.squeeze(1)
            
            batch_roi_max_classes_no_threshold = []   
            batch_roi_max_classes = []
      
            #feature = pooled_feat
            #w = self.RCNN_cls_score.weight
            #cls_score = F.linear(feature, w)
            
            #print('inside   ' + str(saved_feature.size()))
            select_index =torch.LongTensor( np.random.randint(len(saved_cls), size=96)).cuda()
            select_feature = saved_feature[select_index]
            select_feature_n = F.normalize(select_feature, p=2, dim=1)
            
            
            cls_label = saved_cls[select_index]
            
            
            index_for_fg =torch.LongTensor( np.where(rois_label.cpu().numpy()>0)[0]).cuda()
            fg_num = len(np.where(rois_label.cpu().numpy()>0)[0])
            index_for_bg =torch.LongTensor( npr.choice(np.where(rois_label.cpu().numpy()==0)[0], size=fg_num, replace=False)).cuda()
            
            #print(pooled_feat.size())
            #print('saved_feature    '+str(saved_feature.size()))
            
         
            '''
            index_for_mixup =torch.LongTensor( np.where(rois_label.cpu().numpy()>0)[0]).cuda()
            feature_for_mixup = pooled_feat[index_for_mixup]
            label_for_mixup = rois_label[index_for_mixup]
            '''

            #feature_for_mixup = pooled_feat
            #label_for_mixup = rois_label
            ###feature_for_mixup = torch.cat((pooled_feat[index_for_bg],pooled_feat[index_for_fg]),dim=0)
            ###label_for_mixup = torch.cat((rois_label[index_for_bg],rois_label[index_for_fg]),dim = 0)
            
            feature_for_mixup = torch.cat((pooled_feat[index_for_bg],pooled_feat[index_for_fg]),dim=0)
            label_for_mixup = torch.cat((rois_label[index_for_bg],rois_label[index_for_fg]),dim = 0)
            '''
            feature_for_mixup = torch.cat((feature_for_mixup,select_feature[index_for_fg]),dim=0)
            label_for_mixup = torch.cat((label_for_mixup,cls_label[index_for_fg]),dim = 0)
            

            mixed_feature, target_a , target_b , lam = mixup_data(feature_for_mixup, label_for_mixup, lam=lam)
            
            mixed_feature = F.normalize(mixed_feature, p=2, dim=1)
            '''
            
            #feature_for_mixup = torch.cat((feature_for_mixup,select_feature[index_for_fg]),dim=0)
            #label_for_mixup = torch.cat((label_for_mixup,cls_label[index_for_fg]),dim = 0)
            

            mixed_feature, target_a , target_b , lam = mixup_data_sep(feature_for_mixup, label_for_mixup,select_feature,cls_label, lam=lam)
            
            mixed_feature = F.normalize(mixed_feature, p=2, dim=1)
            
            
            
            feature = F.normalize(pooled_feat, p=2, dim=1)
            feature = torch.cat((feature,select_feature_n),dim=0)
            rois_label = torch.cat((rois_label,cls_label),dim = 0)
            
            
            
            w = self.RCNN_cls_score.weight
            w = F.normalize(w, dim=1, p=2)
            mixed_logit =  F.linear(mixed_feature, w)
            mixed_score = F.linear(mixed_feature, w)*torch.FloatTensor([10]).cuda()
            
            raw_logit =  F.linear(feature, w)
            cls_score = F.linear(feature, w)*torch.FloatTensor([10]).cuda()
        
            RCNN_loss_cls = 0
            RCNN_loss_bbox = 0
            
            if self.training:
                # classification loss
                cls_prob =  F.softmax(cls_score, dim = 1)
                #print(cls_prob.size())
                numpy_label = rois_label.cpu().numpy()
                fg_index = torch.LongTensor(np.where(numpy_label>0)[0]).cuda()
                #print(len(fg_index))
                
                RCNN_loss_cls = F.cross_entropy(cls_score, rois_label)+ 0.2*mixup_criterion(criterion, mixed_score, target_a, target_b, lam)
                #RCNN_loss_cls =  F.cross_entropy(cls_score, rois_label)+ 5*drift_loss(cls_score, rois_label,cls_index) 
                
                
      
                RCNN_loss_bbox = _smooth_l1_loss(bbox_pred, rois_target, rois_inside_ws, rois_outside_ws)
                #mixup_loss = mixup_criterion(criterion, mixed_score, target_a, target_b, lam)
                
                
            #print(batch_roi_max_classes_no_threshold.size())
 
            return rois,rpn_loss_cls, rpn_loss_bbox, RCNN_loss_cls, RCNN_loss_bbox
        elif train_agnoist_rcnn:
            criterion = nn.CrossEntropyLoss()
            lam = np.random.beta(2, 2)
            bbox_pred = self.RCNN_bbox_pred(pooled_feat)
            if self.training and not self.class_agnostic:
                # select the corresponding columns according to roi labels
                bbox_pred_view = bbox_pred.view(bbox_pred.size(0), int(bbox_pred.size(1) / 4), 4)
                bbox_pred_select = torch.gather(bbox_pred_view, 1,
                                                rois_label.view(rois_label.size(0), 1, 1).expand(rois_label.size(0), 1,
                                                                                                 4))
                bbox_pred = bbox_pred_select.squeeze(1)
            
            batch_roi_max_classes_no_threshold = []   
            batch_roi_max_classes = []
      
            #feature = pooled_feat
            #w = self.RCNN_cls_score.weight
            #cls_score = F.linear(feature, w)
           
            #feature_for_mixup = pooled_feat
            #label_for_mixup = rois_label
          
            
            #mixed_feature, target_a , target_b , lam = mixup_data(feature_for_mixup, label_for_mixup, lam=lam)
            
            #mixed_feature = F.normalize(mixed_feature, p=2, dim=1)
            
            
            feature = F.normalize(pooled_feat, p=2, dim=1)
 
            w = self.RCNN_cls_score.weight
            w = F.normalize(w, dim=1, p=2)
            
            #mixed_logit =  F.linear(mixed_feature, w)
            #mixed_score = F.linear(mixed_feature, w)*torch.FloatTensor([10]).cuda()
            
            raw_logit =  F.linear(feature, w)
            cls_score = F.linear(feature, w)*torch.FloatTensor([10]).cuda()
        
            RCNN_loss_cls = 0
            RCNN_loss_bbox = 0
            index_for_fg =torch.LongTensor( np.where(rois_label.cpu().numpy()>0)[0]).cuda()
            rois_label[index_for_fg] = 1
            if self.training:
                # classification loss
                cls_prob =  F.softmax(cls_score, dim = 1)
              
                RCNN_loss_cls = F.cross_entropy(cls_score, rois_label)#+ 5*drift_loss(cls_score, rois_label,cls_index) 
           
                # bounding box regression L1 loss
                RCNN_loss_bbox = _smooth_l1_loss(bbox_pred, rois_target, rois_inside_ws, rois_outside_ws)
                
                
                
            #print(batch_roi_max_classes_no_threshold.size())
 
            return rois,rpn_loss_cls, rpn_loss_bbox, RCNN_loss_cls, RCNN_loss_bbox
        
        elif train_specific_rcnn:
            criterion = nn.CrossEntropyLoss()
            lam = np.random.beta(2, 2)
            bbox_pred = self.RCNN_bbox_pred(pooled_feat)
            if self.training and not self.class_agnostic:
                # select the corresponding columns according to roi labels
                bbox_pred_view = bbox_pred.view(bbox_pred.size(0), int(bbox_pred.size(1) / 4), 4)
                bbox_pred_select = torch.gather(bbox_pred_view, 1,
                                                rois_label.view(rois_label.size(0), 1, 1).expand(rois_label.size(0), 1,
                                                                                                 4))
                bbox_pred = bbox_pred_select.squeeze(1)
            
            batch_roi_max_classes_no_threshold = []   
            batch_roi_max_classes = []
      
            #feature = pooled_feat
            #w = self.RCNN_cls_score.weight
            #cls_score = F.linear(feature, w)
           
            #feature_for_mixup = pooled_feat
            #label_for_mixup = rois_label
          
            
            #mixed_feature, target_a , target_b , lam = mixup_data(feature_for_mixup, label_for_mixup, lam=lam)
            
            #mixed_feature = F.normalize(mixed_feature, p=2, dim=1)
            
            
            feature = F.normalize(pooled_feat, p=2, dim=1)
 
            w = self.RCNN_cls_score.weight
            w = F.normalize(w, dim=1, p=2)
            
            #mixed_logit =  F.linear(mixed_feature, w)
            #mixed_score = F.linear(mixed_feature, w)*torch.FloatTensor([10]).cuda()
            
            raw_logit =  F.linear(feature, w)
            cls_score = F.linear(feature, w)*torch.FloatTensor([10]).cuda()
        
            RCNN_loss_cls = 0
            RCNN_loss_bbox = 0
            index_for_fg =torch.LongTensor( np.where(rois_label.cpu().numpy()>0)[0]).cuda()
            rois_label = rois_label - 1
            if self.training:
                # classification loss
                cls_prob =  F.softmax(cls_score, dim = 1)
              
                RCNN_loss_cls = F.cross_entropy(cls_score[index_for_fg], rois_label[index_for_fg])#+ 5*drift_loss(cls_score, rois_label,cls_index) 
           
                # bounding box regression L1 loss
                RCNN_loss_bbox = _smooth_l1_loss(bbox_pred, rois_target, rois_inside_ws, rois_outside_ws)
                
                
                
            #print(batch_roi_max_classes_no_threshold.size())
 
            return rois,rpn_loss_cls, rpn_loss_bbox, RCNN_loss_cls, RCNN_loss_bbox
        else:
            criterion = nn.CrossEntropyLoss()
            lam = np.random.beta(2, 2)
            bbox_pred = self.RCNN_bbox_pred(pooled_feat)
            if self.training and not self.class_agnostic:
                # select the corresponding columns according to roi labels
                bbox_pred_view = bbox_pred.view(bbox_pred.size(0), int(bbox_pred.size(1) / 4), 4)
                bbox_pred_select = torch.gather(bbox_pred_view, 1,
                                                rois_label.view(rois_label.size(0), 1, 1).expand(rois_label.size(0), 1,
                                                                                                 4))
                bbox_pred = bbox_pred_select.squeeze(1)
            
            batch_roi_max_classes_no_threshold = []   
            batch_roi_max_classes = []
      
            #feature = pooled_feat
            #w = self.RCNN_cls_score.weight
            #cls_score = F.linear(feature, w)
           
            #feature_for_mixup = pooled_feat
            #label_for_mixup = rois_label
          
            
            #mixed_feature, target_a , target_b , lam = mixup_data(feature_for_mixup, label_for_mixup, lam=lam)
            
            #mixed_feature = F.normalize(mixed_feature, p=2, dim=1)
            
            
            feature = F.normalize(pooled_feat, p=2, dim=1)
 
            w = self.RCNN_cls_score.weight
            w = F.normalize(w, dim=1, p=2)
            
            #mixed_logit =  F.linear(mixed_feature, w)
            #mixed_score = F.linear(mixed_feature, w)*torch.FloatTensor([10]).cuda()
            
            raw_logit =  F.linear(feature, w)
            cls_score = F.linear(feature, w)*torch.FloatTensor([10]).cuda()
        
            RCNN_loss_cls = 0
            RCNN_loss_bbox = 0
            
            if self.training:
                # classification loss
                cls_prob =  F.softmax(cls_score, dim = 1)
                #if cls_index ==None:
                 #   RCNN_loss_cls = F.cross_entropy(cls_score, rois_label)
                #else:
                RCNN_loss_cls = F.cross_entropy(cls_score, rois_label)#+ 5*drift_loss(cls_score, rois_label,cls_index) 
           
                # bounding box regression L1 loss
                RCNN_loss_bbox = _smooth_l1_loss(bbox_pred, rois_target, rois_inside_ws, rois_outside_ws)
                
                
                
            #print(batch_roi_max_classes_no_threshold.size())
 
            return rois,rpn_loss_cls, rpn_loss_bbox, RCNN_loss_cls, RCNN_loss_bbox
        
       
           
    def _init_weights(self):
        def normal_init(m, mean, stddev, truncated=False):
            """
            weight initalizer: truncated normal and random normal.
            """
            # x is a parameter
            if truncated:
                m.weight.data.normal_().fmod_(2).mul_(stddev).add_(mean)  # not a perfect approximation
            else:
                m.weight.data.normal_(mean, stddev)
                m.bias.data.zero_()
        def normal_init_cls(m, mean, stddev, truncated=False):
            """
            weight initalizer: truncated normal and random normal.
            """
            # x is a parameter
            if truncated:
                m.weight.data.normal_().fmod_(2).mul_(stddev).add_(mean)  # not a perfect approximation
            else:
                m.weight.data.normal_(mean, stddev)
        
        normal_init(self.RCNN_rpn.RPN_Conv, 0, 0.01, cfg.TRAIN.TRUNCATED)
        normal_init(self.RCNN_rpn.RPN_cls_score, 0, 0.01, cfg.TRAIN.TRUNCATED)
        normal_init(self.RCNN_rpn.RPN_bbox_pred, 0, 0.01, cfg.TRAIN.TRUNCATED)
        normal_init_cls(self.RCNN_cls_score, 0, 0.01, cfg.TRAIN.TRUNCATED)
        normal_init(self.RCNN_bbox_pred, 0, 0.001, cfg.TRAIN.TRUNCATED)
        
        
   
    
    def create_architecture(self):
        self._init_modules()
        self._init_weights()
        




def box_aug(pred_box,num):
    batch_size = num
    new_box =[]
    for i in range(batch_size):
        box = pred_box[i]
        w = box[2] - box[0]
        h = box[3] - box[1]
        mean_x = 0
        sigma_x = w/15
        d_x = np.random.normal(mean_x , sigma_x ,2)
        
        mean_y = 0
        sigma_y = h/15
        #print('d_x    '+str(sigma_x*2)+'   d_y   '+str(sigma_y*2))
        d_y = np.random.normal(mean_y , sigma_y ,2)
        
        box[0] = np.max(box[0] + d_x[0] , 0)
        box[2] = np.max(box[2] + d_x[1] , 0)
        
        box[1] = np.max(box[1] + d_y[0] , 0)
        box[3] = np.max(box[3] + d_y[1] , 0)
        new_box.append(torch.FloatTensor(box).unsqueeze(0))
        
    new_box = torch.cat(new_box , dim=0)
    #print(new_box.size())
    return new_box
        
        
        
