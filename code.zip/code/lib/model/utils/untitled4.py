#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Dec 21 18:59:44 2019

@author: liyiting1
"""
import os
novel_class = ['bird', 'bus', 'cow', 'motorbike', 'sofa']
train_path = "/home/liyiting1/Desktop/MetaR-CNN-master/data/VOCdevkit2007/VOC2007/ImageSets/Main/test.txt"
full_list = []
for line in open(train_path):
    full_list.append(line)
    
unseen_list = []
for i in range(len(novel_class)):
    novel_path = "/home/liyiting1/Desktop/MetaR-CNN-master/data/VOCdevkit2007/VOC2007/ImageSets/Main/" + novel_class[i] + "_test.txt"
 
    for line in open(novel_path):
       image_id = line.split()[0]
       image_flag = int(line.split()[1])
       if image_flag == 1:
           #print("1")
           if image_id+"\n" in full_list:
              full_list.remove(image_id+'\n')
              unseen_list.append(image_id+'\n')
           
base_path  = open(("/home/liyiting1/Desktop/MetaR-CNN-master/data/VOCdevkit2007/VOC2007/ImageSets/Main/test_base.txt"), 'w')
#novel_path_1  = open(("/home/liyiting1/Desktop/MetaR-CNN-master/data/VOCdevkit2007/VOC2007/ImageSets/Main/test_novel.txt"), 'w')  
print(unseen_list)
for i in range(len(full_list)):
    base_path.write(full_list[i])
#for j in range(len(unseen_list)):
    #novel_path_1.write(unseen_list[j])
        
           