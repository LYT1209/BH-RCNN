"""Transform a roidb into a trainable roidb by adding a bunch of metadata."""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
import pickle
import datasets
import numpy as np
from model.utils.config import cfg
from datasets.factory import get_imdb
import PIL
import pdb
import collections

def prepare_roidb(imdb):
  """Enrich the imdb's roidb by adding some derived quantities that
  are useful for training. This function precomputes the maximum
  overlap, taken over ground-truth boxes, between each ROI and
  each ground-truth box. The class with maximum overlap is also
  recorded.
  """

  roidb = imdb.roidb
  if not (imdb.name.startswith('coco') or imdb.name.startswith('vg')):
    sizes = [PIL.Image.open(imdb.image_path_at(i)).size
         for i in range(imdb.num_images)]
         
  for i in range(len(imdb.image_index)):
    roidb[i]['img_id'] = imdb.image_id_at(i)
    roidb[i]['image'] = imdb.image_path_at(i)
    if not (imdb.name.startswith('coco') or imdb.name.startswith('vg')):
      roidb[i]['width'] = sizes[i][0]
      roidb[i]['height'] = sizes[i][1]
    # need gt_overlaps as a dense array for argmax
    gt_overlaps = roidb[i]['gt_overlaps'].toarray()
    # max overlap with gt over classes (columns)
    max_overlaps = gt_overlaps.max(axis=1)
    # gt class that had the max overlap
    max_classes = gt_overlaps.argmax(axis=1)
    roidb[i]['max_classes'] = max_classes
    roidb[i]['max_overlaps'] = max_overlaps
    # sanity checks
    # max overlap of 0 => class should be zero (background)
    zero_inds = np.where(max_overlaps == 0)[0]
    assert all(max_classes[zero_inds] == 0)
    # max overlap > 0 => class should not be zero (must be a fg class)
    nonzero_inds = np.where(max_overlaps > 0)[0]
    assert all(max_classes[nonzero_inds] != 0)

def update_keyvalue(rdb, idx):
    ## update the roidb keyvaule
    r = rdb.copy()
    keys = ['gt_classes','boxes']
    for k in keys:
        if isinstance(r[k], list):
            r[k] = [rdb[k][idx]]
        elif isinstance(r[k], np.ndarray):
            r[k] = np.array(rdb[k[idx]], dtype=r[k].dtype)
    return r


def filter_class_roidb(roidb, shot, imdb):
  class_count = collections.defaultdict(int)
  for cls in range(1, len(imdb.classes)):
      class_count[cls] = 0
  new_roidb = []
  length = len(roidb) // 2 # consider the flipped
  print('roidb_type '+str(type(roidb)))
  print('roidb length '+str(len(roidb)))
  for idx, rdb in enumerate(roidb[:length]):
    boxes = []
    gt_classes = []
    gt_overlaps = []
    max_classes = []
    max_overlaps = []

    boxes_flipped = []
    gt_classes_flipped = []
    gt_overlaps_flipped = []
    max_classes_flipped = []
    max_overlaps_flipped = []
    rdb_flipped = roidb[idx + length]
    for i in range(len(rdb['gt_classes'])):
      cls_id = rdb['gt_classes'][i]
      if class_count[cls_id] < shot and cls_id > 15:
        boxes.append(rdb['boxes'][i])
        gt_classes.append(rdb['gt_classes'][i])
        gt_overlaps.append(rdb['gt_overlaps'][i])
        max_classes.append(rdb['max_classes'][i])
        max_overlaps.append(rdb['max_overlaps'][i])

        boxes_flipped.append(rdb_flipped['boxes'][i])
        gt_classes_flipped.append(rdb_flipped['gt_classes'][i])
        gt_overlaps_flipped.append(rdb_flipped['gt_overlaps'][i])
        max_classes_flipped.append(rdb_flipped['max_classes'][i])
        max_overlaps_flipped.append(rdb_flipped['max_overlaps'][i])
        class_count[cls_id] += 1
        ### not original
        break

      elif cls_id <= 15:
        boxes.append(rdb['boxes'][i])
        gt_classes.append(rdb['gt_classes'][i])
        gt_overlaps.append(rdb['gt_overlaps'][i])
        max_classes.append(rdb['max_classes'][i])
        max_overlaps.append(rdb['max_overlaps'][i])

        boxes_flipped.append(rdb_flipped['boxes'][i])
        gt_classes_flipped.append(rdb_flipped['gt_classes'][i])
        gt_overlaps_flipped.append(rdb_flipped['gt_overlaps'][i])
        max_classes_flipped.append(rdb_flipped['max_classes'][i])
        max_overlaps_flipped.append(rdb_flipped['max_overlaps'][i])
        class_count[cls_id] += 1

    if len(boxes) > 0:
      new_roidb.append(
        {'boxes': np.array(boxes, dtype=np.uint16), 'gt_classes': np.array(gt_classes, dtype=np.int32),
         'gt_overlaps': gt_overlaps, 'flipped': rdb['flipped'], 'img_id': rdb['img_id'],
         'image': rdb['image'],
         'width': rdb['width'], 'height': rdb['height'], 'max_classes': np.array(max_classes),
         'need_crop': rdb['need_crop'],
         'max_overlaps': np.array(max_overlaps, dtype=np.float32)})

      new_roidb.append(
        {'boxes': np.array(boxes_flipped, dtype=np.uint16),
         'gt_classes': np.array(gt_classes_flipped, dtype=np.int32),
         'gt_overlaps': gt_overlaps_flipped, 'flipped': rdb_flipped['flipped'],
         'img_id': rdb_flipped['img_id'],
         'image': rdb_flipped['image'],
         'width': rdb_flipped['width'], 'height': rdb_flipped['height'],
         'max_classes': np.array(max_classes_flipped),
         'need_crop': rdb_flipped['need_crop'],
         'max_overlaps': np.array(max_overlaps_flipped, dtype=np.float32)})
  print('new_roidb length '+str(len(new_roidb)))
  return new_roidb

def filter_class_roidb_phase2(roidb, shot, imdb):
  class_count = collections.defaultdict(int)
  for cls in range(1, len(imdb.classes)):
      class_count[cls] = 0
  new_roidb = []
  length = len(roidb) // 2 # consider the flipped
  print('roidb_type '+str(type(roidb)))
  print('roidb length '+str(len(roidb)))
  for idx, rdb in enumerate(roidb[:length]):
    if len(roidb[idx]['boxes']) == 0:
        continue
    boxes = []
    gt_classes = []
    gt_overlaps = []
    max_classes = []
    max_overlaps = []

    boxes_flipped = []
    gt_classes_flipped = []
    gt_overlaps_flipped = []
    max_classes_flipped = []
    max_overlaps_flipped = []
    rdb_flipped = roidb[idx + length]
    
    class_count_temp = class_count.copy()
    for i in range(len(rdb['gt_classes'])):
        cls_id = rdb['gt_classes'][i]
        class_count_temp[cls_id] += 1
    novel_num_exceed = 0
    base_num_exceed = 0
    for i in range(len(rdb['gt_classes'])):
      cls_id = rdb['gt_classes'][i]
      if class_count_temp[cls_id] > shot and cls_id > 60:
          novel_num_exceed = novel_num_exceed + 1
      elif class_count_temp[cls_id] > 0*shot and cls_id <= 60:
          base_num_exceed = base_num_exceed + 1
    if novel_num_exceed > 0:
        continue
    
    contain_needed_novel_obj = 0
    for i in range(len(rdb['gt_classes'])):
        cls_id = rdb['gt_classes'][i]
        if cls_id > 60 and class_count_temp[cls_id] <= shot:
            contain_needed_novel_obj = contain_needed_novel_obj + 1
            
    contain_needed_base_obj = 0
    for i in range(len(rdb['gt_classes'])):
        cls_id = rdb['gt_classes'][i]
        if cls_id <= 60 and class_count_temp[cls_id] <= 0*shot:
            contain_needed_base_obj = contain_needed_base_obj + 1
            
    if novel_num_exceed == 0 and base_num_exceed > 0:
        if contain_needed_novel_obj ==0 or contain_needed_base_obj == 0:
            continue
        
    for i in range(len(rdb['gt_classes'])):
      cls_id = rdb['gt_classes'][i]
      if class_count[cls_id] < shot and cls_id > 60:
        boxes.append(rdb['boxes'][i])
        gt_classes.append(rdb['gt_classes'][i])
        gt_overlaps.append(rdb['gt_overlaps'][i])
        max_classes.append(rdb['max_classes'][i])
        max_overlaps.append(rdb['max_overlaps'][i])

        boxes_flipped.append(rdb_flipped['boxes'][i])
        gt_classes_flipped.append(rdb_flipped['gt_classes'][i])
        gt_overlaps_flipped.append(rdb_flipped['gt_overlaps'][i])
        max_classes_flipped.append(rdb_flipped['max_classes'][i])
        max_overlaps_flipped.append(rdb_flipped['max_overlaps'][i])
        class_count[cls_id] += 1
        

      elif cls_id <= 60:
        boxes.append(rdb['boxes'][i])
        gt_classes.append(rdb['gt_classes'][i])
        gt_overlaps.append(rdb['gt_overlaps'][i])
        max_classes.append(rdb['max_classes'][i])
        max_overlaps.append(rdb['max_overlaps'][i])

        boxes_flipped.append(rdb_flipped['boxes'][i])
        gt_classes_flipped.append(rdb_flipped['gt_classes'][i])
        gt_overlaps_flipped.append(rdb_flipped['gt_overlaps'][i])
        max_classes_flipped.append(rdb_flipped['max_classes'][i])
        max_overlaps_flipped.append(rdb_flipped['max_overlaps'][i])
        class_count[cls_id] += 1

    if len(boxes) > 0:
      new_roidb.append(
        {'boxes': np.array(boxes, dtype=np.uint16), 'gt_classes': np.array(gt_classes, dtype=np.int32),
         'gt_overlaps': gt_overlaps, 'flipped': rdb['flipped'], 'img_id': rdb['img_id'],
         'image': rdb['image'],
         'width': rdb['width'], 'height': rdb['height'], 'max_classes': np.array(max_classes),
         'need_crop': rdb['need_crop'],
         'max_overlaps': np.array(max_overlaps, dtype=np.float32)})

      new_roidb.append(
        {'boxes': np.array(boxes_flipped, dtype=np.uint16),
         'gt_classes': np.array(gt_classes_flipped, dtype=np.int32),
         'gt_overlaps': gt_overlaps_flipped, 'flipped': rdb_flipped['flipped'],
         'img_id': rdb_flipped['img_id'],
         'image': rdb_flipped['image'],
         'width': rdb_flipped['width'], 'height': rdb_flipped['height'],
         'max_classes': np.array(max_classes_flipped),
         'need_crop': rdb_flipped['need_crop'],
         'max_overlaps': np.array(max_overlaps_flipped, dtype=np.float32)})
  print('new_roidb length '+str(len(new_roidb)))
  print(class_count)
  return new_roidb


def filter_class_roidb_phase2_resample(roidb, shot, imdb, resample):
  class_count = collections.defaultdict(int)
  for cls in range(1, len(imdb.classes)):
      class_count[cls] = 0
  new_roidb = []
  novel_roidb = []
  length = len(roidb) // 2 # consider the flipped
  print('roidb_type '+str(type(roidb)))
  print('roidb length '+str(len(roidb)))
  for idx, rdb in enumerate(roidb[:length]):
    if len(roidb[idx]['boxes']) == 0:
        continue
    boxes = []
    gt_classes = []
    gt_overlaps = []
    max_classes = []
    max_overlaps = []

    boxes_flipped = []
    gt_classes_flipped = []
    gt_overlaps_flipped = []
    max_classes_flipped = []
    max_overlaps_flipped = []
    rdb_flipped = roidb[idx + length]
    
    class_count_temp = class_count.copy()
    for i in range(len(rdb['gt_classes'])):
        cls_id = rdb['gt_classes'][i]
        class_count_temp[cls_id] += 1
    novel_num_exceed = 0
    base_num_exceed = 0
    for i in range(len(rdb['gt_classes'])):
      cls_id = rdb['gt_classes'][i]
      if class_count_temp[cls_id] > shot and cls_id > 60:
          novel_num_exceed = novel_num_exceed + 1
      elif class_count_temp[cls_id] > 1000*shot and cls_id <= 60: ##imprint 5
          base_num_exceed = base_num_exceed + 1
    if novel_num_exceed > 0:
        continue
    
    contain_needed_novel_obj = 0
    for i in range(len(rdb['gt_classes'])):
        cls_id = rdb['gt_classes'][i]
        if cls_id > 60 and class_count_temp[cls_id] <= shot:
            contain_needed_novel_obj = contain_needed_novel_obj + 1
            
    contain_needed_base_obj = 0
    for i in range(len(rdb['gt_classes'])):
        cls_id = rdb['gt_classes'][i]
        if cls_id <= 60 and class_count_temp[cls_id] <= 1000*shot:
            contain_needed_base_obj = contain_needed_base_obj + 1
            
    if novel_num_exceed == 0 and base_num_exceed > 0:
        if contain_needed_novel_obj ==0 or contain_needed_base_obj == 0:
            continue
    use_this_novel = 0
    for i in range(len(rdb['gt_classes'])):
      cls_id = rdb['gt_classes'][i]
      if class_count[cls_id] < shot and cls_id > 60:
        boxes.append(rdb['boxes'][i])
        gt_classes.append(rdb['gt_classes'][i])
        gt_overlaps.append(rdb['gt_overlaps'][i])
        max_classes.append(rdb['max_classes'][i])
        max_overlaps.append(rdb['max_overlaps'][i])

        boxes_flipped.append(rdb_flipped['boxes'][i])
        gt_classes_flipped.append(rdb_flipped['gt_classes'][i])
        gt_overlaps_flipped.append(rdb_flipped['gt_overlaps'][i])
        max_classes_flipped.append(rdb_flipped['max_classes'][i])
        max_overlaps_flipped.append(rdb_flipped['max_overlaps'][i])
        class_count[cls_id] += 1
        use_this_novel = use_this_novel+1

      elif cls_id <= 60:
        boxes.append(rdb['boxes'][i])
        gt_classes.append(rdb['gt_classes'][i])
        gt_overlaps.append(rdb['gt_overlaps'][i])
        max_classes.append(rdb['max_classes'][i])
        max_overlaps.append(rdb['max_overlaps'][i])

        boxes_flipped.append(rdb_flipped['boxes'][i])
        gt_classes_flipped.append(rdb_flipped['gt_classes'][i])
        gt_overlaps_flipped.append(rdb_flipped['gt_overlaps'][i])
        max_classes_flipped.append(rdb_flipped['max_classes'][i])
        max_overlaps_flipped.append(rdb_flipped['max_overlaps'][i])
        class_count[cls_id] += 1
    if use_this_novel>0:
        for i in range(use_this_novel):
            novel_roidb.append(
                {'boxes': np.array(boxes, dtype=np.uint16), 'gt_classes': np.array(gt_classes, dtype=np.int32),
                 'gt_overlaps': gt_overlaps, 'flipped': rdb['flipped'], 'img_id': rdb['img_id'],
                 'image': rdb['image'],
                 'width': rdb['width'], 'height': rdb['height'], 'max_classes': np.array(max_classes),
                 'need_crop': rdb['need_crop'],
                 'max_overlaps': np.array(max_overlaps, dtype=np.float32)})
    
            novel_roidb.append(
                {'boxes': np.array(boxes_flipped, dtype=np.uint16),
                 'gt_classes': np.array(gt_classes_flipped, dtype=np.int32),
                 'gt_overlaps': gt_overlaps_flipped, 'flipped': rdb_flipped['flipped'],
                 'img_id': rdb_flipped['img_id'],
                 'image': rdb_flipped['image'],
                 'width': rdb_flipped['width'], 'height': rdb_flipped['height'],
                 'max_classes': np.array(max_classes_flipped),
                 'need_crop': rdb_flipped['need_crop'],
                 'max_overlaps': np.array(max_overlaps_flipped, dtype=np.float32)})
    if use_this_novel>0:
        for k in range(resample):
            new_roidb.append(
            {'boxes': np.array(boxes, dtype=np.uint16), 'gt_classes': np.array(gt_classes, dtype=np.int32),
             'gt_overlaps': gt_overlaps, 'flipped': rdb['flipped'], 'img_id': rdb['img_id'],
             'image': rdb['image'],
             'width': rdb['width'], 'height': rdb['height'], 'max_classes': np.array(max_classes),
             'need_crop': rdb['need_crop'],
             'max_overlaps': np.array(max_overlaps, dtype=np.float32)})

            new_roidb.append(
            {'boxes': np.array(boxes_flipped, dtype=np.uint16),
             'gt_classes': np.array(gt_classes_flipped, dtype=np.int32),
             'gt_overlaps': gt_overlaps_flipped, 'flipped': rdb_flipped['flipped'],
             'img_id': rdb_flipped['img_id'],
             'image': rdb_flipped['image'],
             'width': rdb_flipped['width'], 'height': rdb_flipped['height'],
             'max_classes': np.array(max_classes_flipped),
             'need_crop': rdb_flipped['need_crop'],
             'max_overlaps': np.array(max_overlaps_flipped, dtype=np.float32)})
    if len(boxes) > 0:
      new_roidb.append(
        {'boxes': np.array(boxes, dtype=np.uint16), 'gt_classes': np.array(gt_classes, dtype=np.int32),
         'gt_overlaps': gt_overlaps, 'flipped': rdb['flipped'], 'img_id': rdb['img_id'],
         'image': rdb['image'],
         'width': rdb['width'], 'height': rdb['height'], 'max_classes': np.array(max_classes),
         'need_crop': rdb['need_crop'],
         'max_overlaps': np.array(max_overlaps, dtype=np.float32)})

      new_roidb.append(
        {'boxes': np.array(boxes_flipped, dtype=np.uint16),
         'gt_classes': np.array(gt_classes_flipped, dtype=np.int32),
         'gt_overlaps': gt_overlaps_flipped, 'flipped': rdb_flipped['flipped'],
         'img_id': rdb_flipped['img_id'],
         'image': rdb_flipped['image'],
         'width': rdb_flipped['width'], 'height': rdb_flipped['height'],
         'max_classes': np.array(max_classes_flipped),
         'need_crop': rdb_flipped['need_crop'],
         'max_overlaps': np.array(max_overlaps_flipped, dtype=np.float32)})
  print('new_roidb length '+str(len(new_roidb)))
  with open( './dcr_net_ft/novel_data.pkl', 'wb') as f:
            pickle.dump(novel_roidb, f, pickle.HIGHEST_PROTOCOL)
  print(class_count)
  print('novel+data '+str(len(novel_roidb)))
  return new_roidb


def filter_class_roidb_coco(roidb, shot, imdb):
  class_count = collections.defaultdict(int)
  for cls in range(1, len(imdb.classes)):
      class_count[cls] = 0
  new_roidb = []
  print('roidb_type '+str(type(roidb)))
  print('roidb length '+str(len(roidb)))
  
  class_count = collections.defaultdict(int)
  for cls in range(1, len(imdb.classes)):
      class_count[cls] = 0
      
  for idx, rdb in enumerate(roidb[:]):
    boxes = []
    gt_classes = []
    gt_overlaps = []
    max_classes = []
    max_overlaps = []

   
    num_novel_obj = 0
    #print(rdb['gt_classes'])
    for i in range(len(rdb['gt_classes'])):
        cls_id = rdb['gt_classes'][i]
        if cls_id > 60:
            num_novel_obj = num_novel_obj + 1
    if num_novel_obj > 0:
        continue
    
    for i in range(len(rdb['gt_classes'])):
      
        boxes.append(rdb['boxes'][i])
        gt_classes.append(rdb['gt_classes'][i])
        gt_overlaps.append(rdb['gt_overlaps'][i])
        max_classes.append(rdb['max_classes'][i])
        max_overlaps.append(rdb['max_overlaps'][i])

      
    if len(boxes) > 0:
      new_roidb.append(
        {'boxes': np.array(boxes, dtype=np.uint16), 'gt_classes': np.array(gt_classes, dtype=np.int32),
         'gt_overlaps': gt_overlaps, 'flipped': rdb['flipped'], 'img_id': rdb['img_id'],
         'image': rdb['image'],
         'width': rdb['width'], 'height': rdb['height'], 'max_classes': np.array(max_classes),
         'need_crop': rdb['need_crop'],
         'max_overlaps': np.array(max_overlaps, dtype=np.float32)})

  return new_roidb



def filter_class_roidb_for_reweight(roidb, shot, imdb):
  class_count = collections.defaultdict(int)
  for cls in range(1, 61):
      class_count[cls] = 0
  new_roidb = []
  base_roidb = []
  print('roidb_type '+str(type(roidb)))
  print('roidb length '+str(len(roidb)))
  for idx, rdb in enumerate(roidb[:]):
    boxes = []
    gt_classes = []
    gt_overlaps = []
    max_classes = []
    max_overlaps = []


    num_base_obj = 0
    #print(rdb['gt_classes'])
    for i in range(len(rdb['gt_classes'])):
        cls_id = rdb['gt_classes'][i]
        if cls_id <= 60:
            num_base_obj = num_base_obj + 1
    if num_base_obj == 0:
        continue
    
    class_count_temp = class_count.copy()
    for i in range(len(rdb['gt_classes'])):
        cls_id = rdb['gt_classes'][i]
        if cls_id<=60:
            class_count_temp[cls_id] += 1
    use_this_base = 0
    if max(class_count_temp.values()) <= 10:
        use_this_base = 1
    
    resample_rate = 0
    for i in range(len(rdb['gt_classes'])):
      cls_id = rdb['gt_classes'][i]
      

      if cls_id <= 60:
        boxes.append(rdb['boxes'][i])
        gt_classes.append(rdb['gt_classes'][i])
        gt_overlaps.append(rdb['gt_overlaps'][i])
        max_classes.append(rdb['max_classes'][i])
        max_overlaps.append(rdb['max_overlaps'][i])
        if use_this_base == 1:
            class_count[cls_id] += 1
            resample_rate = resample_rate+1
       
    if use_this_base == 1:
        for k in range(resample_rate):
            base_roidb.append(
            {'boxes': np.array(boxes, dtype=np.uint16), 'gt_classes': np.array(gt_classes, dtype=np.int32),
             'gt_overlaps': gt_overlaps, 'flipped': rdb['flipped'], 'img_id': rdb['img_id'],
             'image': rdb['image'],
             'width': rdb['width'], 'height': rdb['height'], 'max_classes': np.array(max_classes),
             'need_crop': rdb['need_crop'],
             'max_overlaps': np.array(max_overlaps, dtype=np.float32)})
    else:
        if len(boxes) > 0:
          new_roidb.append(
            {'boxes': np.array(boxes, dtype=np.uint16), 'gt_classes': np.array(gt_classes, dtype=np.int32),
             'gt_overlaps': gt_overlaps, 'flipped': rdb['flipped'], 'img_id': rdb['img_id'],
             'image': rdb['image'],
             'width': rdb['width'], 'height': rdb['height'], 'max_classes': np.array(max_classes),
             'need_crop': rdb['need_crop'],
             'max_overlaps': np.array(max_overlaps, dtype=np.float32)})

  with open( './dcr_net_ft/base_data_all_10_shots.pkl', 'wb') as f:
            pickle.dump(base_roidb, f, pickle.HIGHEST_PROTOCOL)
  print('new_roidb length '+str(len(base_roidb)))
  print(class_count)
  return new_roidb

def filter_class_roidb_coco_with_novel(roidb, shot, imdb):
  class_count = collections.defaultdict(int)
  for cls in range(1, len(imdb.classes)):
      class_count[cls] = 0
  new_roidb = []
  print('roidb_type '+str(type(roidb)))
  print('roidb length '+str(len(roidb)))
  for idx, rdb in enumerate(roidb[:]):
    boxes = []
    gt_classes = []
    gt_overlaps = []
    max_classes = []
    max_overlaps = []


    num_base_obj = 0
    #print(rdb['gt_classes'])
    for i in range(len(rdb['gt_classes'])):
        cls_id = rdb['gt_classes'][i]
        if cls_id <= 60:
            num_base_obj = num_base_obj + 1
    if num_base_obj == 0:
        continue
    
    for i in range(len(rdb['gt_classes'])):
      cls_id = rdb['gt_classes'][i]
      

      if cls_id <= 60:
        boxes.append(rdb['boxes'][i])
        gt_classes.append(rdb['gt_classes'][i])
        gt_overlaps.append(rdb['gt_overlaps'][i])
        max_classes.append(rdb['max_classes'][i])
        max_overlaps.append(rdb['max_overlaps'][i])
 
       

    if len(boxes) > 0:
      new_roidb.append(
        {'boxes': np.array(boxes, dtype=np.uint16), 'gt_classes': np.array(gt_classes, dtype=np.int32),
         'gt_overlaps': gt_overlaps, 'flipped': rdb['flipped'], 'img_id': rdb['img_id'],
         'image': rdb['image'],
         'width': rdb['width'], 'height': rdb['height'], 'max_classes': np.array(max_classes),
         'need_crop': rdb['need_crop'],
         'max_overlaps': np.array(max_overlaps, dtype=np.float32)})

     
  print('new_roidb length '+str(len(new_roidb)))
  return new_roidb

def rank_roidb_ratio(roidb):
    # rank roidb based on the ratio between width and height.
    ratio_large = 2 # largest ratio to preserve.
    ratio_small = 0.5 # smallest ratio to preserve.    
    
    ratio_list = []
    for i in range(len(roidb)):
      width = roidb[i]['width']
      height = roidb[i]['height']
      ratio = width / float(height)

      if ratio > ratio_large:
        roidb[i]['need_crop'] = 1
        ratio = ratio_large
      elif ratio < ratio_small:
        roidb[i]['need_crop'] = 1
        ratio = ratio_small        
      else:
        roidb[i]['need_crop'] = 0

      ratio_list.append(ratio)

    ratio_list = np.array(ratio_list)
    ratio_index = np.argsort(ratio_list)
    return ratio_list[ratio_index], ratio_index

def filter_roidb(roidb):
    # filter the image without bounding box.
    print('before filtering, there are %d images...' % (len(roidb)))
    i = 0
    while i < len(roidb):
      if len(roidb[i]['boxes']) == 0:
        del roidb[i]
        i -= 1
      i += 1

    print('after filtering, there are %d images...' % (len(roidb)))
    return roidb

def combined_roidb(imdb_names, phase=1, training=True):
  """
  Combine multiple roidbs
  """

  def get_training_roidb(imdb):
    """Returns a roidb (Region of Interest database) for use in training."""
    if cfg.TRAIN.USE_FLIPPED:
      print('Appending horizontally-flipped training examples...')
      imdb.append_flipped_images()
      print('done')

    print('Preparing training data...')

    prepare_roidb(imdb)
    print('done')
    return imdb.roidb
  
  def get_roidb(imdb_name):
    imdb = get_imdb(imdb_name)
    print('Loaded dataset `{:s}` for training'.format(imdb.name))
    imdb.set_proposal_method(cfg.TRAIN.PROPOSAL_METHOD) #gt
    print('Set proposal method: {:s}'.format(cfg.TRAIN.PROPOSAL_METHOD))
    roidb = get_training_roidb(imdb)
    return roidb

  roidbs = [get_roidb(s) for s in imdb_names.split('+')]
  roidb = roidbs[0]

  if len(roidbs) > 1:
    for r in roidbs[1:]:
      roidb.extend(r)
    tmp = get_imdb(imdb_names.split('+')[1])
    imdb = datasets.imdb.imdb(imdb_names, tmp.classes)
  else:
    imdb = get_imdb(imdb_names)

  if training and phase==1:
    roidb = filter_roidb(roidb)

  ratio_list, ratio_index = rank_roidb_ratio(roidb)

  return imdb, roidb, ratio_list, ratio_index
