
import _init_paths
import os
import sys
import numpy as np
import argparse
import pprint
import pdb
import time
import collections
import torch
import torch.nn as nn
import torch.optim as optim
import random
from model.utils.net_utils import _smooth_l1_loss
import torch.nn.functional as F
from tensorboardX import SummaryWriter

from copy import deepcopy
from torch.utils.data.sampler import Sampler
from torch.autograd import Variable
import torch.utils.data as Data
from lib.roi_data_layer.roidb import combined_roidb, rank_roidb_ratio
from lib.roi_data_layer.roibatchLoader import roibatchLoader
from model.utils.config import cfg, cfg_from_file, cfg_from_list, get_output_dir
from model.utils.net_utils import weights_normal_init, save_net, load_net, \
    adjust_learning_rate, save_checkpoint, clip_gradient
from model.faster_rcnn.resnet import resnet
import pickle

from collections import OrderedDict

# from model.nms.nms_wrapper import nms
from model.roi_layers import nms
from model.rpn.bbox_transform import bbox_transform_inv
from model.rpn.bbox_transform import clip_boxes


from collections import OrderedDict

def parse_args():
    """
    Parse input arguments
    """
    parser = argparse.ArgumentParser(description='Train Meta R-CNN network')
    parser.add_argument('--mGPUs', dest='mGPUs',
                      help='whether use multiple GPUs',
                      action='store_true')
    # Define training data and Model
    parser.add_argument('--dataset', dest='dataset',
                        help='training dataset:coco2017,coco,pascal_07_12',
                        default='pascal_voc_0712', type=str)
    parser.add_argument('--net', dest='net',
                        help='metarcnn',
                        default='metarcnn', type=str)
    # Define display and save dir
    parser.add_argument('--start_epoch', dest='start_epoch',
                        help='starting epoch',
                        default=1, type=int)
    parser.add_argument('--epochs', dest='max_epochs',
                        help='number of epochs to train',
                        default=21, type=int)
    parser.add_argument('--disp_interval', dest='disp_interval',
                        help='number of iterations to display',
                        default=100, type=int)
    parser.add_argument('--checkpoint_interval', dest='checkpoint_interval',
                        help='number of iterations to display',
                        default=10000, type=int)
    parser.add_argument('--save_dir', dest='save_dir',
                        help='directory to save models', default="./models",
                        type=str)
    # Define training parameters
    parser.add_argument('--nw', dest='num_workers',
                        help='number of worker to load data',
                        default=0, type=int)
    parser.add_argument('--cuda', dest='cuda', default=True, type=bool,
                        help='whether use CUDA')
    parser.add_argument('--bs', dest='batch_size',
                        help='batch_size',
                        default=1, type=int)
    parser.add_argument('--cag', dest='class_agnostic', default=False, type=bool,
                        help='whether perform class_agnostic bbox regression')
    # Define meta parameters
   
    parser.add_argument('--phase', dest='phase',
                        help='the phase of training process',
                        default=1, type=int)
    parser.add_argument('--shots', dest='shots',
                        help='the number meta input of PRN network',
                        default=1, type=int)
    parser.add_argument('--meta_type', dest='meta_type', default=1, type=int,
                        help='choose which sets of metaclass')
    # config optimization
    parser.add_argument('--o', dest='optimizer',
                      help='training optimizer',
                      default="sgd", type=str)
    parser.add_argument('--lr', dest='lr',
                      help='starting learning rate',
                      default=0.01, type=float) #use for phase 1 batchs size 12
                      #default=0.0025, type=float) ### use for phase 2 batch size 6
    parser.add_argument('--lr_decay_step', dest='lr_decay_step',
                      help='step to do learning rate decay, unit is epoch',
                      default=4, type=int)
    parser.add_argument('--lr_decay_gamma', dest='lr_decay_gamma',
                      help='learning rate decay ratio',
                      default=0.1, type=float)
    # set training session
    parser.add_argument('--s', dest='session',
                        help='training session',
                        default=1, type=int)
    # resume trained model
    parser.add_argument('--r', dest='resume',
                        help='resume checkpoint or not',
                        default=False, type=bool)
    parser.add_argument('--checksession', dest='checksession',
                        help='checksession to load model',
                        default=1, type=int)
    parser.add_argument('--checkepoch', dest='checkepoch',
                        help='checkepoch to load model',
                        default=1, type=int)
    parser.add_argument('--checkpoint', dest='checkpoint',
                        help='checkpoint to load model',
                        default=21985, type=int)
    # log and diaplay
    parser.add_argument('--use_tfboard', dest='use_tfboard',
                        help='whether use tensorflow tensorboard',
                        default=True, type=bool)
    parser.add_argument('--log_dir', dest='log_dir',
                        help='directory to save logs', default='logs',
                        type=str)
    parser.add_argument('--joint_phase2_dcr', default=False, type=bool,)
    
   
    args = parser.parse_args()
    return args


def accuracy(output, labels, topk=(1,)):
    """Computes the precision@k for the specified values of k"""
    #print(output.max(1).shape)
    preds=output.argmax(axis = 1)
    
    correct=np.equal(preds,labels)
    correct=correct.sum()
    
    return correct/len(labels)
def load_base_dataloader(batch_size):    

    imdb, _, _, _ = combined_roidb(args.imdb_name, phase = 2)

    roidb_novel_1 = pickle.load(open('./dcr_net_ft/base_data_all_10_shots.pkl', 'rb'))
    
    #print(len(roidb)/60)
    #print(len(roidb_novel)/20)

    roidb = roidb_novel_1
    
    ratio_list, ratio_index = rank_roidb_ratio(roidb)
    imdb.set_roidb(roidb)
    print('{:d} novel roidb entries'.format(len(roidb)))
    train_size = len(roidb)/batch_size
    sampler_batch = sampler(train_size, batch_size)
    dataset = roibatchLoader(roidb, ratio_list, ratio_index, batch_size, imdb.num_classes, training=True)
    dataloader = torch.utils.data.DataLoader(dataset, batch_size=batch_size,
                                             sampler=sampler_batch, num_workers=0, pin_memory=False)
    return dataloader,train_size
'''
def load_novel_dataloader(batch_size,start_clss):    


    roidb_novel_1 = pickle.load(open('./dcr_net_ft/novel_class_only_'+str(start_clss)+'_'+str(start_clss)+'.pkl', 'rb'))
    roidb = pickle.load(open('./dcr_net_ft/novel_class_only_'+str(start_clss)+'_'+str(start_clss)+'.pkl', 'rb'))

    roidb.extend(roidb_novel_1)
    roidb.extend(roidb_novel_1)
    roidb.extend(roidb_novel_1)
    roidb.extend(roidb_novel_1)
    ratio_list, ratio_index = rank_roidb_ratio(roidb)
    imdb.set_roidb(roidb)
    print('{:d} novel roidb entries'.format(len(roidb)))
    train_size = len(roidb)
    sampler_batch = sampler(train_size, batch_size)
    dataset = roibatchLoader(roidb, ratio_list, ratio_index, batch_size, imdb.num_classes, training=True)
    dataloader = torch.utils.data.DataLoader(dataset, batch_size=batch_size,
                                             sampler=sampler_batch, num_workers=0, pin_memory=False)
    return dataloader,train_size
'''

def load_novel_dataloader(batch_size,start_clss,step=1):    


    roidb_novel_1 = pickle.load(open('./dcr_net_ft/novel_class_only_'+str(start_clss)+'_'+str(start_clss)+'.pkl', 'rb'))
    roidb = pickle.load(open('./dcr_net_ft/novel_class_only_'+str(start_clss)+'_'+str(start_clss)+'.pkl', 'rb'))

    roidb.extend(roidb_novel_1)
    roidb.extend(roidb_novel_1)
    roidb.extend(roidb_novel_1)
    roidb.extend(roidb_novel_1)
    ratio_list, ratio_index = rank_roidb_ratio(roidb)
    imdb.set_roidb(roidb)
    print('{:d} novel roidb entries'.format(len(roidb)))
    train_size = len(roidb)
    sampler_batch = sampler(train_size, batch_size)
    dataset = roibatchLoader(roidb, ratio_list, ratio_index, batch_size, imdb.num_classes, training=True)
    dataloader = torch.utils.data.DataLoader(dataset, batch_size=batch_size,
                                             sampler=sampler_batch, num_workers=0, pin_memory=False)
    return dataloader,train_size

'''
def load_novel_dataloader(batch_size,start_clss):    

    roidb_novel_1 = pickle.load(open('./dcr_net_ft/novel_data_20_step_10shot_'+str(start_clss)+'_'+str(start_clss)+'.pkl', 'rb'))
    roidb = pickle.load(open('./dcr_net_ft/novel_data_20_step_10shot_'+str(start_clss)+'_'+str(start_clss)+'.pkl', 'rb'))
    roidb.extend(roidb_novel_1)
    roidb.extend(roidb_novel_1)
    roidb.extend(roidb_novel_1)
    

    ratio_list, ratio_index = rank_roidb_ratio(roidb)



    imdb.set_roidb(roidb)
    print('{:d} novel roidb entries'.format(len(roidb)))
    train_size = len(roidb)
    sampler_batch = sampler(train_size, batch_size)
    dataset = roibatchLoader(roidb, ratio_list, ratio_index, batch_size, imdb.num_classes, training=True)
    dataloader = torch.utils.data.DataLoader(dataset, batch_size=batch_size,
                                             sampler=sampler_batch, num_workers=0, pin_memory=False)
    return dataloader,train_size
'''



def softmax_mse_loss(input_logits, target_logits):
    """Takes softmax on both sides and returns MSE loss
    Note:
    - Returns the sum over all examples. Divide by the batch size afterwards
      if you want the mean.
    - Sends gradients to inputs but not the targets.
    """
    assert input_logits.size() == target_logits.size()
    input_softmax = F.softmax(input_logits, dim=1)
    target_softmax = F.softmax(target_logits, dim=1)
    num_classes = input_logits.size()[1]
    return F.mse_loss(input_softmax, target_softmax, size_average=False) / num_classes

def l2_loss(base_model,current_model):
    l2_lambda = 0.001
    l2_reg = torch.tensor(0.).cuda()

    m = 0
    for param in current_model.module.RCNN_top.parameters():
        n = 0
        for param_1 in base_model.module.RCNN_top.parameters():
            if n == m:
                #print(m)
                #print(n)
                #print(param.size())
                #print(param_1.size())
                l2_reg = l2_reg +  torch.norm(param-param_1.detach())
                break
            else:
                n = n +1
                
                
        m = m +1

    m = 0
    for param in current_model.module.RCNN_cls_score.parameters():
        n = 0
        for param_1 in base_model.module.RCNN_cls_score.parameters():
            if n == m:
                l2_reg = l2_reg +  torch.norm(param-param_1.detach())
                break
            else:
                n = n +1
                
                
        m = m +1
        
        
    m = 0
    for param in current_model.module.RCNN_bbox_pred.parameters():
        n = 0
        for param_1 in base_model.module.RCNN_bbox_pred.parameters():
            if n == m:
                l2_reg = l2_reg +  torch.norm(param-param_1.detach())
                break
            else:
                n = n +1
                
                
        m = m +1
    return l2_lambda *l2_reg


 





class EWC(object):
    def __init__(self, label, percentage,roi_reg_targets , roi_inside_ws, roi_outside_ws ,classification_weights,regression_weights,model: nn.Module, dataset: list):

        self.model = model
        self.percentage = percentage
        self.dataset = dataset
        self.label = label
        self.roi_reg_targets = roi_reg_targets
        self.roi_inside_ws = roi_inside_ws
        self.roi_outside_ws = roi_outside_ws
        self.classification_weights = classification_weights
        self.regression_weights = regression_weights
        self.params = {n: p for n, p in self.model.named_parameters() if p.requires_grad}
        self._means = {}
        self._precision_matrices = self._diag_fisher()

        for n, p in deepcopy(self.params).items():
            self._means[n] = p.data

    def _diag_fisher(self):
        precision_matrices = {}
        #for n, p in deepcopy(self.params).items():
        for n, p in self.model.named_parameters():
            if p.requires_grad:
            #p.data.zero_()
                precision_matrices[n] = p.detach().clone().zero_()
                #print(n)
                #print(str(torch.min(precision_matrices[n].data)))

        self.model.eval()
        i = 0 

        
        for input in self.dataset:
            
            self.model.zero_grad()
            #input = variable(input)
            pooled_feat = self.model(input.unsqueeze(0)).mean(3).mean(2)
            bbox_pred = F.linear(pooled_feat,self.regression_weights )

            feature = F.normalize(pooled_feat, p=2, dim=1)
            w = F.normalize(self.classification_weights, dim=1, p=2)
   
            cls_score = F.linear(feature, w)*torch.FloatTensor([10]).cuda()
            
            loss =  F.cross_entropy(cls_score, self.label[i].unsqueeze(0))+_smooth_l1_loss(bbox_pred, self.roi_reg_targets[i], self.roi_inside_ws[i], self.roi_outside_ws[i])
            i = i +1
            loss.backward()

            for n, p in self.model.named_parameters():
                if p.requires_grad:
                    if p.grad is not None:
                        precision_matrices[n].data += p.grad.data ** 2 / len(self.dataset)
     
        channel_attention = 0
        precision_matrices = {n: p for n, p in precision_matrices.items()}

        precision_matrices_copy = {n: p for n, p in precision_matrices.items()}
        for n, p in self.model.named_parameters():
                if p.requires_grad:

                    #print(n)
                    #print(p.size())
                                                      
                 
                    kernel_size = p.size(1)*p.size(2)*p.size(3)
                    resized_tensor = precision_matrices_copy[n].data.view(p.size(0),kernel_size)
                    resized_tensor_1 = torch.sum(resized_tensor,dim=  1)
                    
                    resized_tensor_2 = resized_tensor_1.view(-1)
                    
                    param_number = resized_tensor_2.size(0)
                    topk_number = int(param_number*self.percentage+1)
                    value,index = torch.topk(resized_tensor_2,topk_number)
                    
                    topk_value = torch.min(value)



                    resized_tensor_1 = (resized_tensor_1/topk_value)

                    resized_tensor_1 = torch.where(resized_tensor_1>=0.5,torch.full_like(resized_tensor_1,1),resized_tensor_1)
                    resized_tensor_1 = torch.where(resized_tensor_1<0,torch.full_like(resized_tensor_1,0),resized_tensor_1)
                    resized_tensor_1 = resized_tensor_1.view(p.size(0),1,1,1)
                    resized_tensor_1 = resized_tensor_1.expand(p.size(0),p.size(1),p.size(2),p.size(3))
                    precision_matrices[n].data = resized_tensor_1
                    

        return precision_matrices


class sampler(Sampler):
    def __init__(self, train_size, batch_size):
        self.num_data = train_size
        self.num_per_batch = int(train_size / batch_size)
        self.batch_size = batch_size
        self.range = torch.arange(0, batch_size).view(1, batch_size).long()
        self.leftover_flag = False
        if train_size % batch_size:
            self.leftover = torch.arange(self.num_per_batch * batch_size, train_size).long()
            self.leftover_flag = True

    def __iter__(self):
        rand_num = torch.randperm(self.num_per_batch).view(-1, 1) * self.batch_size
        self.rand_num = rand_num.expand(self.num_per_batch, self.batch_size) + self.range
        self.rand_num_view = self.rand_num.view(-1)

        if self.leftover_flag:
            self.rand_num_view = torch.cat((self.rand_num_view, self.leftover), 0)

        return iter(self.rand_num_view)

    def __len__(self):
        return self.num_data


if __name__ == '__main__':
    args = parse_args()

    print('Called with args:')
    print(args)

    if args.dataset == "coco2017":
        
            args.imdb_name = "coco_2017_train"
            args.imdbval_name = "coco_2017_val"
            args.set_cfgs = ['ANCHOR_SCALES', '[4, 8, 16, 32]', 'ANCHOR_RATIOS', '[0.5,1,2]', 'MAX_NUM_GT_BOXES', '50']
        
            
    elif args.dataset == "coco":
        if args.phase == 1:
            args.imdb_name = "coco_2014_train+coco_2014_valminusminival"
            args.imdbval_name = "coco_2014_minival"
            args.set_cfgs = ['ANCHOR_SCALES', '[ 2,4, 8, 16, 32]', 'ANCHOR_RATIOS', '[0.5,1,2]', 'MAX_NUM_GT_BOXES', '50']
        elif args.phase == 2 :
            args.imdb_name = "coco_2014_train+coco_2014_valminusminival"
            args.imdbval_name = "coco_2014_minival"
            args.set_cfgs = ['ANCHOR_SCALES', '[2,4, 8, 16, 32]', 'ANCHOR_RATIOS', '[0.5,1,2]', 'MAX_NUM_GT_BOXES', '50']
            
    elif args.dataset == "pascal_voc_0712":
       
        if args.phase == 1: # three types of base and novel classes splits
            if args.meta_type == 1:
                args.imdb_name = "voc_2007_train_first_split+voc_2012_train_first_split"
              
            elif args.meta_type == 2:
                args.imdb_name = "voc_2007_train_second_split+voc_2012_train_second_split"
            elif args.meta_type == 3:
                args.imdb_name = "voc_2007_train_third_split+voc_2012_train_third_split"
        elif args.phase == 2 :
            args.imdb_name = "voc_2007_3_shots" # the default sampled shots  saved path of meta classes in the first phase
           

     # the number of sets of metaclass
    cfg.TRAIN.META_TYPE = args.meta_type

    cfg.USE_GPU_NMS = args.cuda
    if args.cuda:
        cfg.CUDA = True

    args.cfg_file = "./cfgs/res50.yml"
    if args.cfg_file is not None:
        cfg_from_file(args.cfg_file)
    if args.set_cfgs is not None:
        cfg_from_list(args.set_cfgs)

    print('Using config:')
    pprint.pprint(cfg)
    np.random.seed(cfg.RNG_SEED)
    if torch.cuda.is_available() and not args.cuda:
        print("WARNING: You have a CUDA device, so you should probably run with --cuda")

   



    

    
    imdb, _, _, _ = combined_roidb(args.imdb_name, phase = 2)
      

    output_dir = args.save_dir
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)



    # initilize the network here
    if args.net == 'metarcnn':
        print(imdb.name)
        print(len(imdb.classes))
        fasterRCNN = resnet(imdb.classes, 101, pretrained=True, class_agnostic=args.class_agnostic,cls_num = 2)
        #fasterRCNN_teacher = resnet(imdb.classes, 50, pretrained=True, class_agnostic=args.class_agnostic,cls_num = 81)
        
        #fasterRCNN_final = resnet(imdb.classes, 50, pretrained=True, class_agnostic=args.class_agnostic,cls_num = 81 )
        
    fasterRCNN.create_architecture()
    

    #fasterRCNN_final.create_architecture()
    # initilize the optimizer here
    if args.phase == 1 :
        lr = cfg.TRAIN.LEARNING_RATE
        lr = 0.005
    else:
        lr = 0.005
    
      
      

      
      
    
      
   
    if args.cuda:
        fasterRCNN.cuda()
        #fasterRCNN_teacher.cuda()
        
        #fasterRCNN_final.cuda()
      
    
    
    
    
    base_ratio = 0.3
   
    
    total_epoch = 7
    

    
    
    DCR_input_list = []
    DCR_input_cls_list = []
    DCR_input = []
    DCR_input_cls = []
    
    importance_matrix = {}
    importance_matrix_original = {}
    new_state_dict_combine = []
    
    
    ###file_record = open( os.path.join(output_dir, 'record.text'),"w")
    for m in range(20):
        frozen_percentage = 0.03#+m*0.005
        pretrain_frozen_percentage =0.03

        DCR_input_list_roi = []
        DCR_input_cls_list_roi = []
        roi_reg_targets = []
        roi_inside_ws = []
        roi_outside_ws = []
        roi_reg_targets_base = []
        roi_inside_ws_base = []
        roi_outside_ws_base = []

        new_list_roi = []
        new_cls_list_roi = []
        new_roi_reg_targets = []
        new_roi_inside_ws = []
        new_roi_outside_ws = []

        DCR_input_roi = []
        DCR_input_cls_roi = []
        step_ratio = 0.02*m
        m_ratio = min(0.5,0.1 + 0.035*m)
        start_class = 61 + 1*m

        fasterRCNN_0 = resnet(imdb.classes, 50, pretrained=True, class_agnostic=args.class_agnostic,cls_num = 2 )         
        fasterRCNN_1 = resnet(imdb.classes, 50, pretrained=True, class_agnostic=args.class_agnostic,cls_num = start_class ) ##63
        fasterRCNN_1_fc = resnet(imdb.classes, 50, pretrained=True, class_agnostic=args.class_agnostic,cls_num = start_class+1 )
        
        fasterRCNN_0.create_architecture()
        fasterRCNN_1.create_architecture()
        fasterRCNN_1_fc.create_architecture()
        
        fasterRCNN_1.cuda()
        fasterRCNN_0.cuda()
        fasterRCNN_1_fc.cuda()
        
        
        params_1 = []
        for key, value in dict(fasterRCNN_1.named_parameters()).items():
          if value.requires_grad:
            if 'bias' in key:
              params_1 += [{'params':[value],'lr':lr*(cfg.TRAIN.DOUBLE_BIAS + 1), \
                      'weight_decay': cfg.TRAIN.BIAS_DECAY and cfg.TRAIN.WEIGHT_DECAY or 0}]
            else:
              params_1 += [{'params':[value],'lr':lr, 'weight_decay': cfg.TRAIN.WEIGHT_DECAY}]
    
        if args.optimizer == "adam":
          lr = lr * 0.1
          optimizer_1 = torch.optim.Adam(params_1)
    
        elif args.optimizer == "sgd":
          #lr = lr * 0.1
          optimizer_1 = torch.optim.SGD(params_1, momentum=cfg.TRAIN.MOMENTUM)
          #optimizer_1 = torch.optim.SGD(params_1, momentum=0)
     
      
    
          
          
          
        params_1_fc = []
        for key, value in dict(fasterRCNN_1_fc.named_parameters()).items():
          if value.requires_grad:
            if 'bias' in key:
              params_1_fc += [{'params':[value],'lr':lr*(cfg.TRAIN.DOUBLE_BIAS + 1), \
                      'weight_decay': cfg.TRAIN.BIAS_DECAY and cfg.TRAIN.WEIGHT_DECAY or 0}]
            else:
              params_1_fc += [{'params':[value],'lr':lr, 'weight_decay': cfg.TRAIN.WEIGHT_DECAY}]
    
        if args.optimizer == "adam":
          lr = lr * 0.1
          optimizer_1_fc = torch.optim.Adam(params_1_fc)
    
        elif args.optimizer == "sgd":
          optimizer_1_fc = torch.optim.SGD(params_1_fc, momentum=cfg.TRAIN.MOMENTUM)
          #optimizer_1_fc = torch.optim.SGD(params_1_fc, momentum=0)
      
        if m >0:
          
            fasterRCNN_1.load_state_dict(new_state_dict_combine)
        else:
            load_name = os.path.join(output_dir,
                                 'coco_metarcnn_1_1_5000_cos_continue.pth')


            #load_name = os.path.join(output_dir,
            #                     'coco_metarcnn_2_6_0_base_ag.pth')
            print("loading checkpoint %s" % (load_name))
            checkpoint = torch.load(load_name)
            new_state_dict_s2 = OrderedDict()
         
            for k, v in checkpoint['model'].items():
                name = k[7:]
                new_state_dict_s2[name] = v
            #fasterRCNN_fc.load_state_dict(checkpoint_fc['model'])
            fasterRCNN_1.load_state_dict(new_state_dict_s2)


        lr = 0.005
    
                        
         
    
        if 'pooling_mode' in checkpoint.keys():
            cfg.POOLING_MODE = checkpoint['pooling_mode']
        print("loaded checkpoint %s" % (load_name))
       
        for p in fasterRCNN_1.RCNN_base[0].parameters(): p.requires_grad=False
        for p in fasterRCNN_1.RCNN_base[1].parameters(): p.requires_grad=False
        for p in fasterRCNN_1.RCNN_base[2].parameters(): p.requires_grad=False
        for p in fasterRCNN_1.RCNN_base[3].parameters(): p.requires_grad=False
        for p in fasterRCNN_1.RCNN_base[4].parameters(): p.requires_grad=False
        for p in fasterRCNN_1.RCNN_base[5].parameters(): p.requires_grad=False
        for p in fasterRCNN_1.RCNN_base[6].parameters(): p.requires_grad=False
        #for p in fasterRCNN.RCNN_top.parameters(): p.requires_grad=False
        for p in fasterRCNN_1.RCNN_rpn.parameters(): p.requires_grad=False
        
        for p in fasterRCNN_1.RCNN_cls_score.parameters(): p[1:start_class,:].detach()
        #for p in fasterRCNN_1.RCNN_cls_score.parameters(): p.requires_grad=False
        for p in fasterRCNN_1.RCNN_bbox_pred.parameters(): p.requires_grad=False
     
       
        fasterRCNN_1.train()

        if m==0:
            im_data = torch.FloatTensor(1)
            im_info = torch.FloatTensor(1)
            num_boxes = torch.LongTensor(1)
            gt_boxes = torch.FloatTensor(1)
            
            # ship to cuda
            if args.cuda:
                im_data = im_data.cuda()
                im_info = im_info.cuda()
                num_boxes = num_boxes.cuda()
                gt_boxes = gt_boxes.cuda()
            
            # make variable
            im_data = Variable(im_data)
            im_info = Variable(im_info)
            num_boxes = Variable(num_boxes)
            gt_boxes = Variable(gt_boxes)

            DCR_input_list_roi_base = []
            DCR_input_cls_list_roi_base = []
            DCR_input_roi_base = []
            DCR_input_cls_roi_base = []
        
            base_dataloader ,base_train_size= load_base_dataloader(4)     
            base_data_iter = iter(base_dataloader)
            for i in range(int(base_train_size)):
                try:
                    data = next(base_data_iter)
                except:
                    base_data_iter = iter(base_dataloader)
                    data = next(base_data_iter)
           
                with torch.no_grad():
                      im_data.resize_(data[0].size()).copy_(data[0])
                      im_info.resize_(data[1].size()).copy_(data[1])
                      gt_boxes.resize_(data[2].size()).copy_(data[2])
                      num_boxes.resize_(data[3].size()).copy_(data[3])
                      
                if im_data.size(0)!=4:
                        continue
                with torch.no_grad():
                    DCR_input_feat,selected_boxes_cls = fasterRCNN_1(im_data, im_info, gt_boxes, num_boxes,extract_feature_wo_normal = True,train_fc = True,start_class = 0)
                    DCR_input_list.append(DCR_input_feat)
                    DCR_input_cls_list.append(selected_boxes_cls)
                    
                  
       
        
        
                    print(im_data.size())
                    if im_data.size(0)!=4:
                        continue
                    DCR_input_feat_roi,selected_boxes_cls_roi ,reg_targets,inside_ws,outside_ws= fasterRCNN_0(im_data, im_info, gt_boxes, num_boxes,extract_ROI_feature_base = True,train_fc = True,start_class = 0)
                    if len(selected_boxes_cls_roi)>0:
                        DCR_input_list_roi_base.append(DCR_input_feat_roi)
                        DCR_input_cls_list_roi_base.append(selected_boxes_cls_roi)
                        roi_reg_targets_base.append(reg_targets)
                        roi_inside_ws_base.append(inside_ws)
                        roi_outside_ws_base.append(outside_ws)
      
            DCR_input = torch.cat(DCR_input_list, dim = 0)
            DCR_input_cls = torch.cat(DCR_input_cls_list, dim = 0)  
            DCR_input_roi_base = torch.cat(DCR_input_list_roi_base, dim = 0)
            DCR_input_cls_roi_base = torch.cat(DCR_input_cls_list_roi_base, dim = 0)
            #numpy_label = DCR_input_cls_roi_base.cpu().numpy()
            #numpy_label[np.where(numpy_label>0)[0]] = 1
            #DCR_input_cls_roi_base = torch.LongTensor(numpy_label).cuda()

            roi_reg_targets_base= torch.cat(roi_reg_targets_base, dim = 0)
            roi_inside_ws_base= torch.cat(roi_inside_ws_base, dim = 0)
            roi_outside_ws_base=torch.cat(roi_outside_ws_base, dim = 0)
     
            
            importance_matrix  = EWC(label =DCR_input_cls_roi_base,percentage=pretrain_frozen_percentage,roi_reg_targets = roi_reg_targets_base, roi_inside_ws = roi_inside_ws_base, roi_outside_ws = roi_outside_ws_base,classification_weights =fasterRCNN_1.RCNN_cls_score.weight.data, regression_weights = fasterRCNN_1.RCNN_bbox_pred.weight.data, model = fasterRCNN_1.RCNN_top, dataset = DCR_input_roi_base )._precision_matrices
            
            
            del  DCR_input_roi_base,DCR_input_cls_roi_base,reg_targets,inside_ws,outside_ws




 



        novel_dataloader ,train_size= load_novel_dataloader(1,start_class)
        
        iters_per_epoch = int(train_size / args.batch_size)
        
        im_data = torch.FloatTensor(1)
        im_info = torch.FloatTensor(1)
        num_boxes = torch.LongTensor(1)
        gt_boxes = torch.FloatTensor(1)
        
          # ship to cuda
        if args.cuda:
          im_data = im_data.cuda()
          im_info = im_info.cuda()
          num_boxes = num_boxes.cuda()
          gt_boxes = gt_boxes.cuda()
        
          # make variable
        im_data = Variable(im_data)
        im_info = Variable(im_info)
        num_boxes = Variable(num_boxes)
        gt_boxes = Variable(gt_boxes)
        global_step = 0
    
        novel_data_iter = iter(novel_dataloader)
    
        
        im_data = torch.FloatTensor(1)
        im_info = torch.FloatTensor(1)
        num_boxes = torch.LongTensor(1)
        gt_boxes = torch.FloatTensor(1)
        
          # ship to cuda
        if args.cuda:
          im_data = im_data.cuda()
          im_info = im_info.cuda()
          num_boxes = num_boxes.cuda()
          gt_boxes = gt_boxes.cuda()
        
          # make variable
        im_data = Variable(im_data)
        im_info = Variable(im_info)
        num_boxes = Variable(num_boxes)
        gt_boxes = Variable(gt_boxes)
    
        #dcr_net.eval()
        global_step = 0
        class_protos = collections.defaultdict(list)
        classes = collections.defaultdict(int)
        for cls in range(81):
                classes[cls] = 0

        
            ###DCR_input = torch.cat(DCR_input_list, dim = 0)
            ###DCR_input_cls = torch.cat(DCR_input_cls_list, dim = 0)
  
        
        for i in range(train_size):
            global_step = global_step+1
            
           
            try:
                    data = next(novel_data_iter)
            except:
                    data_iter = iter(novel_dataloader)
                    data = next(data_iter)
       
            with torch.no_grad():
                  im_data.resize_(data[0].size()).copy_(data[0])
                  im_info.resize_(data[1].size()).copy_(data[1])
                  gt_boxes.resize_(data[2].size()).copy_(data[2])
                  num_boxes.resize_(data[3].size()).copy_(data[3])
            with torch.no_grad():
                dcr_input, dcr_input_cls = fasterRCNN_1(im_data, im_info, gt_boxes, num_boxes,
                                                                             phase = args.phase,train_dcr = False, sample_per_img=32, imprint_rcnn = True,test_dcr = False,start_class = start_class)
            
            #print(dcr_input.requires_grad)
            torch.cuda.empty_cache()
            #print(gt_boxes.size())
            if len(dcr_input)==0:
                continue
            gt_cls = dcr_input_cls.data.cpu().numpy()
            #print(gt_cls)
            #print(gt_cls)    
            if np.max(gt_cls) > 60:
                #print('step1')
                #print(gt_cls)
                selected_index_0 = np.where(gt_cls>60 )[0]
                selected_index_1 = torch.LongTensor(selected_index_0).cuda()
               
                output = dcr_input.data    
                protos_roi = output[selected_index_1]
                proto_cls = gt_cls[selected_index_0]
                #print(proto_roi.size())
                unique_labels = list(np.unique(proto_cls))
                for j in range(len(unique_labels)):
                    name = int(unique_labels[j])
                    classes[name] += 1
                
                for i in range(len(selected_index_0)):
                    cls =proto_cls[i]
                    #print(cls)
                    class_protos[int(cls)].append(protos_roi[i])
                
    
          
                    
              
        for k, v in class_protos.items():
            print(len(v))
        mean_class_protos = {k: sum(v) / len(v) for k, v in class_protos.items()} 
        #print(mean_class_protos)
        
        new_weight = torch.zeros(1, 2048)
        for i in range(start_class,start_class+1):
            tmp = mean_class_protos[i]
            new_weight[i-start_class] = tmp / tmp.norm(p=2)
        
        weight = torch.cat((fasterRCNN_1.RCNN_cls_score.weight.data, new_weight.cuda()))
        fasterRCNN_1.RCNN_cls_score = nn.Linear(2048, start_class+1, bias=False)
        fasterRCNN_1.RCNN_cls_score.weight.data = weight
        #fasterRCNN.n_classes = 21
        #fasterRCNN.RCNN_cls_score.n_classes = 160
        
        save_name = os.path.join(output_dir, '{}_{}_{}_{}_{}.pth'.format(str(args.dataset), str(args.net),str(args.phase),'imprint_10_session',str(m+1)))
        save_checkpoint({
            'session': args.session,
            'epoch': 6,
            'model': fasterRCNN_1.state_dict(),
            
            'pooling_mode': cfg.POOLING_MODE,
            'class_agnostic': args.class_agnostic,
        }, save_name)
            
            
        
        
        
        
        
        
        
        
        load_name = os.path.join(output_dir,
                             'coco_metarcnn_2_imprint_10_session_'+str(m+1)+'.pth')
        print("loading checkpoint %s" % (load_name))
        checkpoint = torch.load(load_name)
        new_state_dict_s2 = OrderedDict()
     
        for k, v in checkpoint['model'].items():
            name = k
            new_state_dict_s2[name] = v
        #fasterRCNN_fc.load_state_dict(checkpoint_fc['model'])
        fasterRCNN_1_fc.load_state_dict(new_state_dict_s2)
        os.remove(load_name)
        #optimizer_1.load_state_dict(checkpoint['optimizer'])
        lr = 0.005
    
                        
         
    
        if 'pooling_mode' in checkpoint.keys():
            cfg.POOLING_MODE = checkpoint['pooling_mode']
        print("loaded checkpoint %s" % (load_name))
    
        for p in fasterRCNN_1_fc.RCNN_base[0].parameters(): p.requires_grad=False
        for p in fasterRCNN_1_fc.RCNN_base[1].parameters(): p.requires_grad=False
        for p in fasterRCNN_1_fc.RCNN_base[2].parameters(): p.requires_grad=False
        for p in fasterRCNN_1_fc.RCNN_base[3].parameters(): p.requires_grad=False
        for p in fasterRCNN_1_fc.RCNN_base[4].parameters(): p.requires_grad=False
        for p in fasterRCNN_1_fc.RCNN_base[5].parameters(): p.requires_grad=False
        for p in fasterRCNN_1_fc.RCNN_base[6].parameters(): p.requires_grad=False
        for p in fasterRCNN_1_fc.RCNN_top.parameters(): p.requires_grad=False
        for p in fasterRCNN_1_fc.RCNN_rpn.parameters(): p.requires_grad=False
        for p in fasterRCNN_1_fc.RCNN_cls_score.parameters(): p[1:start_class,:].detach()
        for p in fasterRCNN_1_fc.RCNN_bbox_pred.parameters(): p.requires_grad=False
        
        
        
        if args.mGPUs:
            fasterRCNN_1_fc = nn.DataParallel(fasterRCNN_1_fc)
            
        fasterRCNN_1_fc.train()
        
        novel_dataloader ,train_size= load_novel_dataloader(4,start_class)
        
        iters_per_epoch = int(train_size / 4)
        for epoch in range(0, 7):
            
           
            loss_temp = 0
            start = time.time()
    
            
    
            #data_iter = iter(dataloader)
            data_iter = iter(novel_dataloader)
            for step in range(iters_per_epoch):
                try:
                    data = next(data_iter)
                    
                except:
                    data_iter = iter(novel_dataloader)
                    data = next(data_iter)
    
              
                global_step = global_step + 1
               
                with torch.no_grad():
                      im_data.resize_(data[0].size()).copy_(data[0])
                      im_info.resize_(data[1].size()).copy_(data[1])
                      gt_boxes.resize_(data[2].size()).copy_(data[2])
                      num_boxes.resize_(data[3].size()).copy_(data[3])
    
              
                fasterRCNN_1_fc.zero_grad()
               
     
                if m == 0:
     
                    rois,rpn_loss_cls, rpn_loss_box, \
                    RCNN_loss_cls, RCNN_loss_bbox = fasterRCNN_1_fc(im_data, im_info, gt_boxes, num_boxes,start_class = start_class,train_fc=True)
                else:
                
  
                    rois,rpn_loss_cls, rpn_loss_box, \
                        RCNN_loss_cls, RCNN_loss_bbox = fasterRCNN_1_fc(im_data, im_info, gt_boxes, num_boxes,saved_feature =torch.cat((DCR_input,DCR_input,DCR_input,DCR_input),dim=0), saved_cls = torch.cat((DCR_input_cls,DCR_input_cls,DCR_input_cls,DCR_input_cls),dim=0),train_with_additional=True,cls_index = start_class-1,start_class = start_class,train_fc=True)
                  
    
                
                loss = RCNN_loss_cls.mean()+  RCNN_loss_bbox.mean()
    
                loss_temp += loss.item()
    
               
                optimizer_1_fc.zero_grad()
                loss.backward()
                # if args.net == "vgg16" or "res101":
                #clip_gradient(fasterRCNN_1_fc, 10.)
                optimizer_1_fc.step()
                dcr_cls_loss=0
                
                if step % args.disp_interval == 0:
                    end = time.time()
                    if step > 0:
                      loss_temp /= (args.disp_interval + 1)
            
                    if args.mGPUs:
                      loss_rpn_cls = rpn_loss_cls.mean().item()
                      loss_rpn_box = rpn_loss_box.mean().item()
                      loss_rcnn_cls = RCNN_loss_cls.mean().item()
                      loss_rcnn_box = RCNN_loss_bbox.mean().item()
     
                      #fg_cnt = torch.sum(rois_label.data.ne(0))
                     # bg_cnt = rois_label.data.numel() - fg_cnt
                    else:
                      loss_rpn_cls = rpn_loss_cls.item()
                      loss_rpn_box = rpn_loss_box.item()
                      loss_rcnn_cls = RCNN_loss_cls.item()
                      loss_rcnn_box = RCNN_loss_bbox.item()
       
                      #fg_cnt = torch.sum(rois_label.data.ne(0))
                      #bg_cnt = rois_label.data.numel() - fg_cnt
            
                    print("[session %d][epoch %2d][iter %4d/%4d] loss: %.4f, lr: %.2e" \
                                            % (args.session, epoch, step, iters_per_epoch, loss_temp, lr))
                    #print("\t\t\tfg/bg=(%d/%d), time cost: %f" % (fg_cnt, bg_cnt, end-start))
                    print("\t\t\trpn_cls: %.4f, rpn_box: %.4f, rcnn_cls: %.4f, rcnn_box %.4f" \
                                  % (loss_rpn_cls, loss_rpn_box, loss_rcnn_cls, loss_rcnn_box))
       
                    if args.use_tfboard:
                      info = {
                        'loss': loss_temp,
                        'loss_rpn_cls': loss_rpn_cls,
                        'loss_rpn_box': loss_rpn_box,
                        'loss_rcnn_cls': loss_rcnn_cls,
                        'loss_rcnn_box': loss_rcnn_box
                      }
                      
            
                    loss_temp = 0
                    start = time.time()
                
                
                
                
                
                
                
                
                if step % 5000 == 0  and epoch>=6:
                    save_name = os.path.join(output_dir, '{}_{}_{}_{}_{}_session_{}_fc.pth'.format(str(args.dataset), str(args.net),str(args.phase),
                                                                                      epoch, step,m+1))
                    save_checkpoint({
                        'session': args.session,
                        'epoch': epoch + 1,
                        'model': fasterRCNN_1_fc.state_dict(),
                        'optimizer': optimizer_1_fc.state_dict(),
                        'pooling_mode': cfg.POOLING_MODE,
                        'class_agnostic': args.class_agnostic,
                    }, save_name)
                    
                    
                    
                    
                    
                    
                    
                    
            
                    
        
        if args.mGPUs:
            fasterRCNN_1 = nn.DataParallel(fasterRCNN_1)
            
        DCR_input_1 = []
        DCR_input_cls_1 = []
        
        
        
        fc_savepoint =  fasterRCNN_1_fc.state_dict()  
        fasterRCNN_1.load_state_dict(fc_savepoint)
        
        
       
        
      
      
        novel_dataloader ,train_size= load_novel_dataloader(4,start_class)
        
        iters_per_epoch = int(train_size / 4)

       

          

      

        
        for epoch in range(0, 8):
            
           
            loss_temp = 0
            start = time.time()
    
            ratio = (base_ratio+step_ratio)*(epoch+1)/total_epoch
            epoch_ratio = (epoch+1)/10
            #data_iter = iter(dataloader)
            data_iter = iter(novel_dataloader)
            for step in range(iters_per_epoch):
                try:
                    data = next(data_iter)
                    
                except:
                    data_iter = iter(novel_dataloader)
                    data = next(data_iter)
    
              
                global_step = global_step + 1
               
                with torch.no_grad():
                      im_data.resize_(data[0].size()).copy_(data[0])
                      im_info.resize_(data[1].size()).copy_(data[1])
                      gt_boxes.resize_(data[2].size()).copy_(data[2])
                      num_boxes.resize_(data[3].size()).copy_(data[3])
                #print('outside '+str(im_data.size()))
                if epoch<7 :
                    

                    fasterRCNN_1.zero_grad()
              
                    rois,rpn_loss_cls, rpn_loss_box, \
                            RCNN_loss_cls, RCNN_loss_bbox = fasterRCNN_1(im_data, im_info, gt_boxes, num_boxes,saved_feature =torch.cat((DCR_input,DCR_input,DCR_input,DCR_input),dim=0), saved_cls = torch.cat((DCR_input_cls,DCR_input_cls,DCR_input_cls,DCR_input_cls),dim=0),train_with_additional=True,cls_index = start_class-1,start_class = start_class,FRCN_old = fasterRCNN_1_fc)
                    

                    
        
                   
                        
                    loss = RCNN_loss_cls.mean()+  RCNN_loss_bbox.mean()# + l2_loss(fasterRCNN_1_fc,fasterRCNN_1)
        
                    loss_temp += loss.item()
        
                   
                    optimizer_1.zero_grad()
                    loss.backward()
                    # if args.net == "vgg16" or "res101":
                    #clip_gradient(fasterRCNN_1, 10.)
                    optimizer_1.step()
                   
                    
                    
                    
                    

                  

                    if step % args.disp_interval == 0:
                        end = time.time()
                        if step > 0:
                          loss_temp /= (args.disp_interval + 1)
                
                        if args.mGPUs:
                          loss_rpn_cls = rpn_loss_cls.mean().item()
                          loss_rpn_box = rpn_loss_box.mean().item()
                          loss_rcnn_cls = RCNN_loss_cls.mean().item()
                          loss_rcnn_box = RCNN_loss_bbox.mean().item()
         
                          #fg_cnt = torch.sum(rois_label.data.ne(0))
                         # bg_cnt = rois_label.data.numel() - fg_cnt
                        else:
                          loss_rpn_cls = rpn_loss_cls.item()
                          loss_rpn_box = rpn_loss_box.item()
                          loss_rcnn_cls = RCNN_loss_cls.item()
                          loss_rcnn_box = RCNN_loss_bbox.item()
           
                        print("[session %d][epoch %2d][iter %4d/%4d] loss: %.4f, lr: %.2e" \
                                                % (args.session, epoch, step, iters_per_epoch, loss_temp, lr))
                        #print("\t\t\tfg/bg=(%d/%d), time cost: %f" % (fg_cnt, bg_cnt, end-start))
                        print("\t\t\trpn_cls: %.4f, rpn_box: %.4f, rcnn_cls: %.4f, rcnn_box %.4f" \
                                      % (loss_rpn_cls, loss_rpn_box, loss_rcnn_cls, loss_rcnn_box))
           
                        if args.use_tfboard:
                          info = {
                            'loss': loss_temp,
                            'loss_rpn_cls': loss_rpn_cls,
                            'loss_rpn_box': loss_rpn_box,
                            'loss_rcnn_cls': loss_rcnn_cls,
                            'loss_rcnn_box': loss_rcnn_box
                          }
                          
                
                        loss_temp = 0
                        start = time.time()
                 
                    
                else:
                    DCR_input_feat,selected_boxes_cls = fasterRCNN_1(im_data, im_info, gt_boxes, num_boxes,extract_feature_wo_normal = True,start_class = start_class,FRCN_old = fasterRCNN_1_fc)
                    DCR_input_list.append(DCR_input_feat)
                    DCR_input_cls_list.append(selected_boxes_cls)
                   
                    DCR_input_feat_roi,selected_boxes_cls_roi ,reg_targets,inside_ws,outside_ws= fasterRCNN_1(im_data, im_info, gt_boxes, num_boxes,extract_ROI_feature = True,start_class = start_class,FRCN_old = fasterRCNN_1_fc)
                    
                    
                    
                    DCR_input_list_roi.append(DCR_input_feat_roi)
                    DCR_input_cls_list_roi.append(selected_boxes_cls_roi)
                    roi_reg_targets.append(reg_targets)
                    roi_inside_ws.append(inside_ws)
                    roi_outside_ws.append(outside_ws)
        savepoint_0 = fasterRCNN_1_fc.state_dict() 
                  
        savepoint_1 = fasterRCNN_1.state_dict()
        new_state_dict_fc_inner = OrderedDict()          
        new_state_dict_ex_inner = OrderedDict()      
        new_state_dict_combine_inner = OrderedDict()
        for k, v in savepoint_0.items():
            name = k
            new_state_dict_fc_inner[name] = v
            
        
        for k, v in savepoint_1.items():
            name = k
            new_state_dict_ex_inner[name] = v
                    
        for k, v in savepoint_0.items():
                name = k
                #print(name)
                for name_1,value_1 in importance_matrix.items():
                    if name == str('module.RCNN_top.'+name_1):
                        
                        new_state_dict_combine_inner[name] = new_state_dict_fc_inner[name]*(0.7) + new_state_dict_ex_inner[name]*(1-0.7)

                    
                    else:
                    
                    
                        new_state_dict_combine_inner[name] = new_state_dict_fc_inner[name]*(0.7) + new_state_dict_ex_inner[name]*(1-0.7)

            ###print('frozen precent '+str(number_frozen/all_param))
        fasterRCNN_1.load_state_dict(new_state_dict_combine_inner)
                    

        save_name = os.path.join(output_dir, '{}_{}_{}_{}_{}_session_{}_ex.pth'.format(str(args.dataset), str(args.net),str(args.phase),
                                                                                          6, 0,m+1))
        save_checkpoint({
                            'session': args.session,
                            'epoch': epoch + 1,
                            'model': fasterRCNN_1.state_dict(),
                            'optimizer': optimizer_1.state_dict(),
                            'pooling_mode': cfg.POOLING_MODE,
                            'class_agnostic': args.class_agnostic,
                        }, save_name)

                
        DCR_input = torch.cat(DCR_input_list, dim = 0)
        DCR_input_cls = torch.cat(DCR_input_cls_list, dim = 0)
        #print('outside   ' + str(DCR_input.size()))
        
        DCR_input_roi = torch.cat(DCR_input_list_roi, dim = 0)
        DCR_input_cls_roi = torch.cat(DCR_input_cls_list_roi, dim = 0)
        roi_reg_targets= torch.cat(roi_reg_targets, dim = 0)
        roi_inside_ws= torch.cat(roi_inside_ws, dim = 0)
        roi_outside_ws=torch.cat(roi_outside_ws, dim = 0)
        #importance_matrix = fasterRCNN_1(estimate_fisher = True,ROI_feature = DCR_input_roi, ROI_label=DCR_input_cls_roi)

        current_matrix  = EWC(label =DCR_input_cls_roi,percentage=frozen_percentage,roi_reg_targets = roi_reg_targets, roi_inside_ws = roi_inside_ws, roi_outside_ws = roi_outside_ws,classification_weights =fasterRCNN_1.module.RCNN_cls_score.weight.data, regression_weights =fasterRCNN_1.module.RCNN_bbox_pred.weight.data,model = fasterRCNN_1.module.RCNN_top, dataset = DCR_input_roi )._precision_matrices
        
        
        
        del DCR_input_cls_roi
        #print('outside   '+str(importance_matrix.size()))
        
  
        for name_1,value_1 in importance_matrix.items():
            #importance_matrix[name_1] = importance_matrix[name_1]*m_ratio + current_matrix[name_1]*(1-m_ratio)
            importance_matrix[name_1] = (importance_matrix[name_1]+ current_matrix[name_1])
            importance_matrix[name_1].data  = torch.where(importance_matrix[name_1].data >1,torch.full_like(importance_matrix[name_1].data ,1),importance_matrix[name_1].data )
               
        

        load_name_fc = os.path.join(output_dir,
                         'coco_metarcnn_2_6_0_session_'+str(m+1)+'_fc.pth')
        print("loading checkpoint %s" % (load_name_fc))
        checkpoint_fc = torch.load(load_name_fc)
        new_state_dict_fc = OrderedDict()
        os.remove(load_name_fc)
        
        load_name_ex = os.path.join(output_dir,
                             'coco_metarcnn_2_6_0_session_'+str(m+1)+'_ex.pth')
        print("loading checkpoint %s" % (load_name_ex))
        checkpoint_ex = torch.load(load_name_ex)
        new_state_dict_ex = OrderedDict()
        
        new_state_dict_combine = OrderedDict()
        for k, v in checkpoint_fc['model'].items():
            name = k[7:]
            new_state_dict_fc[name] = v
            
        
        for k, v in checkpoint_ex['model'].items():
            name = k[7:]
            new_state_dict_ex[name] = v
            
        for k, v in checkpoint_fc['model'].items():
            name = k[7:]
            
            #if m >=0:
             #   new_state_dict_combine[name] = new_state_dict_fc[name]*0.5 + new_state_dict_ex[name]*0.5
            #else:
            new_state_dict_combine[name] = new_state_dict_ex[name]
            #new_state_dict_combine[name] = new_state_dict_fc[name]
        #if m<18:
         #   os.remove(load_name_ex)

                    
